# 🏹 Arrow Master - Complete Mobile-First Offline Archery Game

Arrow Master is a fully self-contained, offline-first archery mobile web game built with TypeScript, React 19, Tailwind CSS, Canvas API, and Web Audio API.

Designed primarily for portrait mobile devices (Android and iOS) as well as desktop browsers, it works 100% offline with zero external API dependencies, zero CDNs, and zero backend requirements.

---

## 🌟 Key Features

- **🎮 Core Archery Gameplay**:
  - 60 FPS HTML5 Canvas physics engine with ballistics, arrow drop, and drag.
  - Multi-zone precision scoring: Dead-center Perfect (+200 pts), Bullseye (+100 pts), Inner ring (+50 pts), Outer ring (+20 pts).
  - Dynamic wind mechanics with real-time direction and strength indicators that push arrows laterally in flight.
  - Moving targets (horizontal, sine wave, ping-pong) and obstacle shields (logs, birds, branches) that deflect arrows.
  - Multiplier & Combo streak system with visual fire badges and screen shake.

- **🗺️ 50 Progressive Levels**:
  - Full campaign from beginner target practice to extreme windy obstacle challenges.
  - 3-star rating progression for every level based on score, accuracy, and remaining arrows.
  - Interactive level select grid with locked/unlocked states and high score records.

- **🏹 Armory & Shop (100% Local Persistence)**:
  - **8 Unique Bows**: Wooden Bow, Hunter Recurve, Silver Sight, Golden Glory, Shadow Recurve, Firestorm Bow, Frostbite Bow, and Royal Sovereign.
  - **6 Enchanted Arrow Skins**: Classic Wood, Silver Tip, Golden Feather, Fire Arrow, Ice Shard, and Thunder Arrow with customized particle trails.
  - Daily offline reward system (+150 coins every 24 hours).
  - 8 milestone achievements with reward coin claims.

- **🔊 Procedural Web Audio Engine**:
  - Synthesized on-device using the Web Audio API—no external MP3/WAV files required.
  - Bow tension pull, whoosh releases, target impact thuds, bullseye fanfares, coin collection chimes, and ambient forest tones.
  - Safe user-gesture audio context handling complying with browser autoplay restrictions.

- **📱 Mobile-First PWA & Offline Support**:
  - Touch-optimized portrait interface with large responsive SHOOT button and touch drag aiming.
  - Full PWA compliance (`manifest.json`, Service Worker caching).
  - Works offline after the initial load.
  - Persistent game state saved in `localStorage`.

---

## 🚀 Getting Started Locally

### Prerequisites
- Node.js (v18 or higher recommended)
- npm (v9 or higher)

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000`.

### 3. Build for Production
```bash
npm run build
```
The optimized production static files will be placed in the `dist/` directory.

---

## 📦 How to Upload to GitHub

1. Initialize a Git repository in the project directory:
   ```bash
   git init
   ```

2. Add all project files:
   ```bash
   git add .
   ```

3. Commit your changes:
   ```bash
   git commit -m "Initial commit: Complete Arrow Master game"
   ```

4. Link to your GitHub repository:
   ```bash
   git branch -M main
   git remote add origin https://github.com/<YOUR_USERNAME>/arrow-master.git
   ```

5. Push to GitHub:
   ```bash
   git push -u origin main
   ```

---

## ⚡ How to Deploy to Vercel

### Option A: Via GitHub (Recommended)
1. Push your repository to GitHub.
2. Go to [Vercel Dashboard](https://vercel.com/dashboard) and click **"Add New Project"**.
3. Import your `arrow-master` repository.
4. Vercel will automatically detect **Vite**:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. Click **"Deploy"**. Your game is now live with an HTTPS URL and global CDN!

### Option B: Via Vercel CLI
```bash
npm install -g vercel
vercel
```
Follow the interactive prompts (defaults work immediately with the included `vercel.json`).

---

## 💻 Multi-Language Implementation

This project contains implementations across multiple languages:

1. **TypeScript / JavaScript**:
   - Primary responsive web client (`src/`), React 19 architecture, Canvas 2D engine, and procedural sound synthesizer.
2. **C++ (C++17)**:
   - Standalone physics simulation, hit-detection engine, and terminal game located in `cpp/` (`cpp/ArrowPhysics.hpp`, `cpp/main.cpp`, `cpp/Makefile`, `cpp/CMakeLists.txt`).
3. **HTML5**:
   - Canvas API, viewport tags for mobile fullscreen mode, and PWA manifest linkages (`index.html`).
4. **CSS3 / Tailwind CSS**:
   - Mobile-first responsive touch layout, forest & wood themes, and custom animations (`src/index.css`).

---

## 🛠️ How to Compile and Run the C++ Edition

To compile the native C++ physics engine and interactive CLI simulation:

```bash
cd cpp

# Using Make (Linux/macOS):
make
./arrow_master

# Or directly with g++:
g++ -std=c++17 main.cpp -O2 -o arrow_master
./arrow_master

# Or using CMake:
cmake -B build
cmake --build build
./build/arrow_master
```

---

## 📁 Project Architecture

```
arrow-master/
├── cpp/                             # C++17 Core Physics & Simulation Edition
│   ├── ArrowPhysics.hpp             # Aerodynamics, gravity, collision math
│   ├── main.cpp                     # Interactive terminal game loop
│   ├── Makefile                     # Make build script
│   └── CMakeLists.txt               # CMake configuration
├── public/
│   ├── icon.svg                     # High-res vector game icon
│   ├── manifest.json                # PWA web manifest
│   ├── service-worker.js            # Offline caching service worker
│   └── arrow-master-complete.zip    # Complete project package (All languages & assets)
├── src/
│   ├── audio/
│   │   └── soundManager.ts          # Procedural Web Audio API synthesizer
│   ├── components/
│   │   ├── ArcheryCanvas.tsx        # 60 FPS Canvas game & physics engine
│   │   ├── GameHUD.tsx              # Mobile HUD (Arrows, Score, Wind, Shoot button)
│   │   ├── HomeScreen.tsx           # Main game menu and stats display
│   │   ├── LevelSelectModal.tsx     # 50-level selection modal
│   │   ├── ShopModal.tsx            # Bow and arrow skins armory
│   │   ├── AchievementsModal.tsx    # Honor achievements and rewards
│   │   ├── SettingsModal.tsx        # Audio/vibration toggles & data export
│   │   ├── PauseModal.tsx           # Pause dialog
│   │   ├── GameOverModal.tsx        # Round failed retry dialog
│   │   ├── LevelCompleteModal.tsx   # Victory fanfare & star rewards
│   │   ├── TutorialModal.tsx        # Interactive guide
│   │   └── PWAInstallBanner.tsx     # In-app PWA install prompt
│   ├── game/
│   │   ├── items.ts                 # Bows & arrow skins catalog
│   │   ├── levels.ts                # 50 calibrated levels configuration
│   │   ├── achievements.ts          # Achievement definitions & progress
│   │   └── storage.ts               # localStorage state manager
│   ├── types.ts                     # TypeScript interfaces & types
│   ├── index.css                    # Tailwind CSS and theme definitions
│   ├── App.tsx                      # Root state machine & view router
│   └── main.tsx                     # React application root
├── index.html                       # HTML5 entry with mobile meta tags
├── package.json                     # Project scripts and dependencies
├── tsconfig.json                    # TypeScript compiler configuration
├── vercel.json                      # Vercel deployment routing configuration
└── README.md                        # Documentation & setup guide
```

---

## 📄 License

Apache-2.0
