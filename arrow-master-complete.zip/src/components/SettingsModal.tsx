import React, { useState } from 'react';
import { ArrowLeft, Volume2, VolumeX, Music, Smartphone, Monitor, RotateCcw, HelpCircle, AlertTriangle, Download } from 'lucide-react';
import { UserSaveState } from '../types';
import { soundManager } from '../audio/soundManager';

interface SettingsModalProps {
  saveState: UserSaveState;
  onUpdateSettings: (partial: Partial<UserSaveState>) => void;
  onResetProgress: () => void;
  onOpenTutorial: () => void;
  onBack: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  saveState,
  onUpdateSettings,
  onResetProgress,
  onOpenTutorial,
  onBack,
}) => {
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b1711] text-slate-100 select-none">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-stone-800/80 bg-stone-950/80 backdrop-blur-md">
        <button
          id="settings-back-button"
          onClick={() => {
            soundManager.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-stone-300 hover:text-white px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 active:scale-95 transition text-sm font-bold"
        >
          <ArrowLeft size={18} />
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black tracking-wide text-amber-300 uppercase">
            SETTINGS
          </h2>
          <span className="text-xs text-stone-400 font-medium">Preferences & Controls</span>
        </div>

        <div className="w-16" />
      </div>

      {/* Settings Options List */}
      <div className="flex-1 overflow-y-auto p-4 max-w-md mx-auto w-full space-y-4">
        {/* Sound FX Toggle */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-stone-900/80 border border-stone-800 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-amber-400 border border-amber-500/20">
              {saveState.soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
            </div>
            <div>
              <div className="text-sm font-black text-white">Sound Effects</div>
              <div className="text-xs text-stone-400">Bow, hits, fanfare, impacts</div>
            </div>
          </div>

          <button
            id="toggle-sound"
            onClick={() => {
              const next = !saveState.soundEnabled;
              onUpdateSettings({ soundEnabled: next });
              soundManager.setPreferences(next, saveState.musicEnabled, saveState.vibrationEnabled);
              if (next) soundManager.playButtonClick();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
              saveState.soundEnabled
                ? 'bg-emerald-500 text-stone-950 shadow-md'
                : 'bg-stone-800 text-stone-400 border border-stone-700'
            }`}
          >
            {saveState.soundEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Music Toggle */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-stone-900/80 border border-stone-800 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-amber-400 border border-amber-500/20">
              <Music size={20} />
            </div>
            <div>
              <div className="text-sm font-black text-white">Background Music</div>
              <div className="text-xs text-stone-400">Atmospheric forest ambience</div>
            </div>
          </div>

          <button
            id="toggle-music"
            onClick={() => {
              const next = !saveState.musicEnabled;
              onUpdateSettings({ musicEnabled: next });
              soundManager.setPreferences(saveState.soundEnabled, next, saveState.vibrationEnabled);
              soundManager.playButtonClick();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
              saveState.musicEnabled
                ? 'bg-emerald-500 text-stone-950 shadow-md'
                : 'bg-stone-800 text-stone-400 border border-stone-700'
            }`}
          >
            {saveState.musicEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Vibration / Haptics Toggle */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-stone-900/80 border border-stone-800 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-amber-400 border border-amber-500/20">
              <Smartphone size={20} />
            </div>
            <div>
              <div className="text-sm font-black text-white">Haptic Vibration</div>
              <div className="text-xs text-stone-400">Tactile recoil and hit feedback</div>
            </div>
          </div>

          <button
            id="toggle-vibration"
            onClick={() => {
              const next = !saveState.vibrationEnabled;
              onUpdateSettings({ vibrationEnabled: next });
              soundManager.setPreferences(saveState.soundEnabled, saveState.musicEnabled, next);
              soundManager.playButtonClick();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition ${
              saveState.vibrationEnabled
                ? 'bg-emerald-500 text-stone-950 shadow-md'
                : 'bg-stone-800 text-stone-400 border border-stone-700'
            }`}
          >
            {saveState.vibrationEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        {/* Graphics Quality */}
        <div className="flex items-center justify-between p-4 rounded-2xl bg-stone-900/80 border border-stone-800 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-amber-400 border border-amber-500/20">
              <Monitor size={20} />
            </div>
            <div>
              <div className="text-sm font-black text-white">Graphics Quality</div>
              <div className="text-xs text-stone-400">Particles & motion trail detail</div>
            </div>
          </div>

          <button
            id="toggle-graphics"
            onClick={() => {
              const next = !saveState.highGraphics;
              onUpdateSettings({ highGraphics: next });
              soundManager.playButtonClick();
            }}
            className="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider bg-stone-800 border border-stone-700 text-amber-300"
          >
            {saveState.highGraphics ? 'HIGH' : 'LOW'}
          </button>
        </div>

        {/* Tutorial Button */}
        <button
          id="settings-tutorial-button"
          onClick={() => {
            soundManager.playButtonClick();
            onOpenTutorial();
          }}
          className="w-full flex items-center justify-between p-4 rounded-2xl bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 shadow-md transition active:scale-95 cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-sky-400 border border-sky-500/20">
              <HelpCircle size={20} />
            </div>
            <div>
              <div className="text-sm font-black text-white">Archery Guide</div>
              <div className="text-xs text-stone-400">Aiming, wind compensation, combos</div>
            </div>
          </div>
          <span className="text-xs font-bold text-sky-300">VIEW</span>
        </button>

        {/* Download Project ZIP Button */}
        <a
          id="download-project-zip-button"
          href="/arrow-master-complete.zip"
          download="arrow-master-complete.zip"
          onClick={() => soundManager.playButtonClick()}
          className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-amber-950/40 to-stone-900 border border-amber-500/30 hover:border-amber-400 shadow-md transition active:scale-95 cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-stone-950 flex items-center justify-center text-amber-400 border border-amber-500/30">
              <Download size={20} />
            </div>
            <div>
              <div className="text-sm font-black text-amber-300">Export Source Code</div>
              <div className="text-xs text-stone-400">arrow-master-complete.zip (GitHub/Vercel)</div>
            </div>
          </div>
          <span className="text-xs font-bold text-amber-300 bg-amber-500/10 px-2 py-1 rounded-md border border-amber-500/20">
            ZIP ↓
          </span>
        </a>

        {/* Reset Progress Button */}
        <div className="pt-4 border-t border-stone-800/80">
          <button
            id="settings-reset-button"
            onClick={() => {
              soundManager.playButtonClick();
              setShowResetConfirm(true);
            }}
            className="w-full flex items-center justify-center gap-2 p-3.5 rounded-2xl bg-red-950/40 border border-red-500/30 text-red-300 text-xs font-black uppercase tracking-wider hover:bg-red-950/60 active:scale-95 transition cursor-pointer"
          >
            <RotateCcw size={16} />
            <span>Reset All Game Progress</span>
          </button>
        </div>
      </div>

      {/* Confirmation Modal for Reset */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-stone-900 border border-red-500/40 p-5 shadow-2xl text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-red-500/20 text-red-400 flex items-center justify-center mx-auto border border-red-500/30">
              <AlertTriangle size={24} />
            </div>
            <h3 className="text-lg font-black text-white">Reset All Progress?</h3>
            <p className="text-xs text-stone-300">
              This will erase all level scores, gold stars, unlocked bows, arrow skins, and coins. This action cannot be undone.
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                id="cancel-reset-button"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowResetConfirm(false);
                }}
                className="flex-1 py-2.5 rounded-xl bg-stone-800 text-stone-300 text-xs font-bold border border-stone-700 active:scale-95 transition"
              >
                Cancel
              </button>
              <button
                id="confirm-reset-button"
                onClick={() => {
                  soundManager.playButtonClick();
                  setShowResetConfirm(false);
                  onResetProgress();
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black uppercase tracking-wider active:scale-95 transition shadow-lg"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
