import React from 'react';
import { ArrowLeft, CheckCircle2, Gift } from 'lucide-react';
import { UserSaveState } from '../types';
import { getEvaluatedAchievements } from '../game/achievements';
import { soundManager } from '../audio/soundManager';

interface AchievementsModalProps {
  saveState: UserSaveState;
  onClaimReward: (achievementId: string, coins: number) => void;
  onBack: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  saveState,
  onClaimReward,
  onBack,
}) => {
  const achievements = getEvaluatedAchievements(saveState);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b1711] text-slate-100 select-none">
      {/* Header Bar */}
      <div className="flex items-center justify-between p-4 border-b border-stone-800/80 bg-stone-950/80 backdrop-blur-md">
        <button
          id="achievements-back-button"
          onClick={() => {
            soundManager.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-stone-300 hover:text-white px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 active:scale-95 transition text-sm font-bold"
        >
          <ArrowLeft size={18} />
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black tracking-wide text-amber-300 uppercase">
            ACHIEVEMENTS
          </h2>
          <span className="text-xs text-stone-400 font-medium">Honor & Rewards</span>
        </div>

        <div className="flex items-center gap-1.5 bg-black/60 border border-amber-500/40 px-3.5 py-1.5 rounded-full shadow-lg">
          <span className="text-amber-400 text-sm font-bold">🪙</span>
          <span className="text-xs sm:text-sm font-black text-amber-300">
            {saveState.coins.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Achievements List */}
      <div className="flex-1 overflow-y-auto p-4 max-w-xl mx-auto w-full">
        <div className="space-y-3 pb-8">
          {achievements.map((ach) => {
            const isClaimed = !!saveState.achievementsClaimed[ach.id];
            const percent = Math.min(100, Math.round((ach.current / ach.target) * 100));

            return (
              <div
                key={ach.id}
                className={`flex items-center justify-between p-3.5 sm:p-4 rounded-2xl border transition-all ${
                  ach.unlocked
                    ? 'bg-stone-900/90 border-amber-500/40 shadow-[0_0_10px_rgba(245,158,11,0.15)]'
                    : 'bg-stone-950/60 border-stone-800/80 opacity-70'
                }`}
              >
                {/* Left: Icon & Description */}
                <div className="flex items-center gap-3 min-w-0 flex-1 mr-3">
                  <div className="w-12 h-12 rounded-xl bg-stone-950 border border-amber-500/30 flex items-center justify-center text-2xl shrink-0 shadow-inner">
                    {ach.icon}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-black text-white truncate">{ach.title}</h3>
                      {ach.unlocked && (
                        <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-stone-400 line-clamp-2 mt-0.5">
                      {ach.description}
                    </p>

                    {/* Progress Bar */}
                    <div className="w-full mt-2 flex items-center gap-2">
                      <div className="flex-1 h-2 rounded-full bg-stone-950 overflow-hidden border border-stone-800">
                        <div
                          className="h-full bg-gradient-to-r from-amber-600 to-yellow-400 transition-all duration-300 rounded-full"
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-bold text-stone-400 whitespace-nowrap">
                        {ach.current} / {ach.target}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Reward / Claim Button */}
                <div className="shrink-0">
                  {isClaimed ? (
                    <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1">
                      <span>Claimed ✓</span>
                    </div>
                  ) : ach.unlocked ? (
                    <button
                      id={`claim-ach-${ach.id}`}
                      onClick={() => {
                        soundManager.playCoin();
                        onClaimReward(ach.id, ach.rewardCoins);
                      }}
                      className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-stone-950 text-xs font-black uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-lg flex items-center gap-1 animate-pulse cursor-pointer"
                    >
                      <Gift size={14} />
                      <span>+{ach.rewardCoins} 🪙</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-stone-900 border border-stone-800 text-[11px] font-bold text-amber-300/80">
                      <span>🪙</span>
                      <span>+{ach.rewardCoins}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
