import React from 'react';
import { RotateCcw, Grid, Home, Target } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface GameOverModalProps {
  score: number;
  bestScore: number;
  coinsEarned: number;
  levelNumber: number;
  onRetry: () => void;
  onLevels: () => void;
  onHome: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  score,
  bestScore,
  coinsEarned,
  levelNumber,
  onRetry,
  onLevels,
  onHome,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-xs rounded-3xl bg-gradient-to-b from-stone-900 to-stone-950 border border-red-500/30 p-6 shadow-2xl text-center space-y-4">
        {/* Header Icon & Title */}
        <div className="space-y-1">
          <div className="w-14 h-14 rounded-full bg-red-500/10 text-red-400 flex items-center justify-center mx-auto border border-red-500/30 mb-2">
            <Target size={28} className="rotate-45" />
          </div>
          <div className="text-xs uppercase tracking-widest text-red-400 font-extrabold">
            Level {levelNumber} Failed
          </div>
          <h2 className="text-2xl font-black text-white tracking-wider uppercase">
            GAME OVER
          </h2>
          <p className="text-xs text-stone-400">Out of arrows! Try again to hit the targets.</p>
        </div>

        {/* Stats Card */}
        <div className="bg-stone-950/80 rounded-2xl p-3.5 border border-stone-800 space-y-2 text-left">
          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 font-bold">Score:</span>
            <span className="text-sm font-black text-white">{score.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 font-bold">Best Score:</span>
            <span className="text-sm font-black text-emerald-400">
              {Math.max(score, bestScore).toLocaleString()}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs pt-1 border-t border-stone-800">
            <span className="text-stone-400 font-bold">Coins Earned:</span>
            <span className="text-sm font-black text-amber-300">+{coinsEarned} 🪙</span>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-1">
          <button
            id="gameover-retry-button"
            onClick={() => {
              soundManager.playButtonClick();
              onRetry();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-black text-base uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={18} />
            <span>RETRY</span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              id="gameover-levels-button"
              onClick={() => {
                soundManager.playButtonClick();
                onLevels();
              }}
              className="py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Grid size={14} />
              <span>Levels</span>
            </button>

            <button
              id="gameover-home-button"
              onClick={() => {
                soundManager.playButtonClick();
                onHome();
              }}
              className="py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Home size={14} />
              <span>Home</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
