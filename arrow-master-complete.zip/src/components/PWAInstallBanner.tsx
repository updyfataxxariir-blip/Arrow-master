import React, { useEffect, useState } from 'react';
import { Download, Share, X } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check if app is in standalone mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  if (isInstalled || dismissed) return null;

  const handleInstallClick = async () => {
    soundManager.playButtonClick();
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredPrompt(null);
    } else if (isIOS) {
      setShowIOSGuide(true);
    }
  };

  return (
    <>
      <div className="w-full max-w-md my-2 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 backdrop-blur-md flex items-center justify-between gap-2 shadow-lg">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-lg">🏹</span>
          <div className="truncate">
            <div className="text-xs font-black text-amber-300">Play Offline Anywhere</div>
            <div className="text-[10px] text-stone-400 truncate">Install Arrow Master on home screen</div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            id="install-pwa-button"
            onClick={handleInstallClick}
            className="px-3 py-1 rounded-lg bg-amber-500 text-stone-950 font-black text-xs uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow flex items-center gap-1"
          >
            <Download size={12} />
            <span>Install</span>
          </button>
          <button
            onClick={() => setDismissed(true)}
            className="p-1 text-stone-500 hover:text-stone-300 active:scale-95 transition"
            aria-label="Dismiss"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* iOS Safari Installation Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xs rounded-2xl bg-stone-900 border border-stone-800 p-5 shadow-2xl text-center space-y-3">
            <h3 className="text-base font-black text-white flex items-center justify-center gap-1.5">
              <span>Install on iPhone / iPad</span>
            </h3>
            <p className="text-xs text-stone-300 leading-relaxed text-left">
              1. Tap the <strong className="text-amber-400">Share</strong> button <Share size={14} className="inline" /> in Safari.<br />
              2. Scroll down and tap <strong className="text-amber-400">Add to Home Screen</strong>.<br />
              3. Launch directly from your home screen with zero lag!
            </p>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-2 rounded-xl bg-stone-800 text-stone-200 text-xs font-bold border border-stone-700 active:scale-95 transition"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
