import React, { useEffect, useState } from 'react';
import { Star, Play, RotateCcw, Home, Sparkles } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface LevelCompleteModalProps {
  levelNumber: number;
  score: number;
  accuracy: number;
  perfectHits: number;
  coinsEarned: number;
  stars: number; // 1, 2, or 3
  hasNextLevel: boolean;
  onNextLevel: () => void;
  onReplay: () => void;
  onHome: () => void;
}

export const LevelCompleteModal: React.FC<LevelCompleteModalProps> = ({
  levelNumber,
  score,
  accuracy,
  perfectHits,
  coinsEarned,
  stars,
  hasNextLevel,
  onNextLevel,
  onReplay,
  onHome,
}) => {
  const [animatedStars, setAnimatedStars] = useState(0);

  // Stagger star reveals for tactile satisfaction
  useEffect(() => {
    soundManager.playLevelComplete();

    const timer1 = setTimeout(() => setAnimatedStars(1), 300);
    const timer2 = setTimeout(() => {
      if (stars >= 2) {
        setAnimatedStars(2);
        soundManager.playCoin();
      }
    }, 650);
    const timer3 = setTimeout(() => {
      if (stars >= 3) {
        setAnimatedStars(3);
        soundManager.playUnlock();
      }
    }, 1000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [stars]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none">
      <div className="relative w-full max-w-sm rounded-3xl bg-gradient-to-b from-stone-900 to-stone-950 border border-amber-500/40 p-6 shadow-2xl text-center space-y-4 overflow-hidden">
        {/* Confetti / celebration glow behind */}
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-48 h-48 bg-amber-500/20 blur-3xl rounded-full pointer-events-none" />

        {/* Title */}
        <div className="space-y-1 relative z-10">
          <div className="flex items-center justify-center gap-1 text-xs uppercase tracking-widest text-emerald-400 font-extrabold">
            <Sparkles size={14} />
            <span>Stage {levelNumber} Cleared</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-wide uppercase drop-shadow">
            🎯 LEVEL COMPLETE!
          </h2>
        </div>

        {/* Animated 3-Star Rating */}
        <div className="flex items-center justify-center gap-2 py-1 relative z-10">
          {[1, 2, 3].map((starIdx) => {
            const isEarned = starIdx <= animatedStars;
            return (
              <div
                key={starIdx}
                className={`transition-all duration-300 transform ${
                  isEarned
                    ? 'scale-110 rotate-0 text-amber-400 fill-amber-400 drop-shadow-[0_0_12px_rgba(245,158,11,0.8)]'
                    : 'scale-90 opacity-30 text-stone-600 fill-stone-800'
                }`}
              >
                <Star size={starIdx === 2 ? 42 : 34} />
              </div>
            );
          })}
        </div>

        {/* Performance Metrics Card */}
        <div className="bg-stone-950/80 rounded-2xl p-4 border border-stone-800/80 space-y-2.5 text-left relative z-10 shadow-inner">
          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 font-bold">Total Score:</span>
            <span className="text-base font-black text-white">{score.toLocaleString()}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 font-bold">Accuracy:</span>
            <span className="text-sm font-black text-sky-400">{accuracy}%</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-stone-400 font-bold">Perfect Bullseyes:</span>
            <span className="text-sm font-black text-yellow-400">{perfectHits} 🔥</span>
          </div>

          <div className="flex items-center justify-between text-xs pt-2 border-t border-stone-800/80">
            <span className="text-stone-400 font-bold">Coins Earned:</span>
            <span className="text-base font-black text-amber-300">+{coinsEarned} 🪙</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1 relative z-10">
          {hasNextLevel ? (
            <button
              id="level-complete-next-button"
              onClick={() => {
                soundManager.playButtonClick();
                onNextLevel();
              }}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-emerald-400 to-teal-500 text-stone-950 font-black text-base uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-[0_8px_20px_rgba(16,185,129,0.35)] flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>NEXT LEVEL</span>
              <Play size={18} fill="currentColor" />
            </button>
          ) : (
            <div className="p-3 bg-amber-500/20 border border-amber-400/40 rounded-xl text-xs font-black text-amber-300">
              🏆 ALL 50 LEVELS COMPLETED! YOU ARE THE GRANDMASTER!
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <button
              id="level-complete-replay-button"
              onClick={() => {
                soundManager.playButtonClick();
                onReplay();
              }}
              className="py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCcw size={14} />
              <span>Replay</span>
            </button>

            <button
              id="level-complete-home-button"
              onClick={() => {
                soundManager.playButtonClick();
                onHome();
              }}
              className="py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-xs uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Home size={14} />
              <span>Home</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
