import React, { useEffect, useRef, useCallback } from 'react';
import { 
  LevelConfig, 
  BowItem, 
  ArrowSkin, 
  FlyingArrow, 
  StuckArrow, 
  Particle, 
  FloatingText, 
  HitResult 
} from '../types';
import { BOWS, ARROW_SKINS } from '../game/items';
import { soundManager } from '../audio/soundManager';

interface ArcheryCanvasProps {
  level: LevelConfig;
  bowId: string;
  arrowSkinId: string;
  arrowsRemaining: number;
  combo: number;
  highGraphics: boolean;
  onShootArrow: () => void;
  onHitResult: (result: HitResult) => void;
  isPaused: boolean;
  canShoot: boolean;
}

export const ArcheryCanvas: React.FC<ArcheryCanvasProps> = ({
  level,
  bowId,
  arrowSkinId,
  arrowsRemaining,
  combo,
  highGraphics,
  onShootArrow,
  onHitResult,
  isPaused,
  canShoot,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Selected gear details
  const bow = BOWS.find((b) => b.id === bowId) || BOWS[0];
  const arrowSkin = ARROW_SKINS.find((a) => a.id === arrowSkinId) || ARROW_SKINS[0];

  // Dynamic game state inside Canvas
  const gameStateRef = useRef({
    // Target position & movement
    targetX: 200,
    targetY: 150,
    targetVx: 1.5,
    targetPhase: 0,
    targetJiggle: 0,
    stuckArrows: [] as StuckArrow[],

    // Obstacles
    obstacleStates: [] as { x: number; y: number; vx: number; width: number; height: number }[],

    // Aiming state
    aimAngle: -Math.PI / 2, // pointing straight up
    targetAimAngle: -Math.PI / 2,
    isDragging: false,
    dragStart: { x: 0, y: 0 },
    bowPull: 0, // 0 to 1 pull strength
    swayTime: 0,

    // Projectile & FX
    flyingArrow: null as FlyingArrow | null,
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    screenShake: 0,
    slowMotionTimer: 0,

    // Dimensions
    width: 400,
    height: 700,
    dpr: 1,

    // Dynamic wind
    currentWind: level.windSpeed,
    windTimer: 0,
  });

  // Keep references synced
  const propsRef = useRef({
    level,
    bow,
    arrowSkin,
    arrowsRemaining,
    combo,
    highGraphics,
    isPaused,
    canShoot,
    onShootArrow,
    onHitResult,
  });

  useEffect(() => {
    propsRef.current = {
      level,
      bow,
      arrowSkin,
      arrowsRemaining,
      combo,
      highGraphics,
      isPaused,
      canShoot,
      onShootArrow,
      onHitResult,
    };
  }, [level, bow, arrowSkin, arrowsRemaining, combo, highGraphics, isPaused, canShoot, onShootArrow, onHitResult]);

  // Reset target and stuck arrows whenever level changes
  useEffect(() => {
    const s = gameStateRef.current;
    s.targetX = s.width * 0.5;
    s.targetY = s.height * 0.22;
    s.targetVx = level.targetSpeed || 1.5;
    s.targetPhase = 0;
    s.targetJiggle = 0;
    s.stuckArrows = [];
    s.flyingArrow = null;
    s.currentWind = level.windSpeed;
    s.aimAngle = -Math.PI / 2;
    s.targetAimAngle = -Math.PI / 2;

    // Initialize obstacles
    s.obstacleStates = level.obstacles.map((obs) => ({
      x: s.width * obs.xRatio,
      y: s.height * obs.yRatio,
      vx: obs.speed,
      width: obs.width,
      height: obs.height,
    }));
  }, [level]);

  // Fire action triggered by HUD or touch release
  const triggerShoot = useCallback(() => {
    const s = gameStateRef.current;
    const { canShoot, arrowsRemaining, onShootArrow, bow, arrowSkin } = propsRef.current;

    if (!canShoot || arrowsRemaining <= 0 || s.flyingArrow) return;

    soundManager.playArrowRelease();

    // Bow origin at bottom
    const bowX = s.width * 0.5;
    const bowY = s.height * 0.84;

    // Speed of arrow
    const speed = 24;
    const vx = Math.cos(s.aimAngle) * speed;
    const vy = Math.sin(s.aimAngle) * speed;

    s.flyingArrow = {
      x: bowX,
      y: bowY,
      vx,
      vy,
      angle: s.aimAngle,
      skinId: arrowSkin.id,
      trail: [],
      active: true,
    };

    s.bowPull = 1; // trigger recoil
    onShootArrow();
  }, []);

  // Expose shoot trigger globally on window for Shoot button
  useEffect(() => {
    (window as unknown as { triggerArrowShoot?: () => void }).triggerArrowShoot = triggerShoot;
    return () => {
      delete (window as unknown as { triggerArrowShoot?: () => void }).triggerArrowShoot;
    };
  }, [triggerShoot]);

  // Handle Resize and Canvas Setup
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const updateSize = () => {
      const rect = container.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;

      const s = gameStateRef.current;
      s.width = rect.width;
      s.height = rect.height;
      s.dpr = dpr;
      s.targetY = rect.height * 0.22;
      if (s.targetX === 200) {
        s.targetX = rect.width * 0.5;
      }
    };

    const ro = new ResizeObserver(updateSize);
    ro.observe(container);
    updateSize();

    return () => ro.disconnect();
  }, []);

  // Input Handlers (Touch, Mouse, Keyboard)
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handlePointerDown = (e: PointerEvent) => {
      const { isPaused, canShoot } = propsRef.current;
      if (isPaused || !canShoot) return;

      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      const s = gameStateRef.current;
      s.isDragging = true;
      s.dragStart = { x: clientX, y: clientY };

      // Calculate aiming vector toward touch point from bow
      const bowX = s.width * 0.5;
      const bowY = s.height * 0.84;
      const dx = clientX - bowX;
      const dy = clientY - bowY;
      // Only aim upwards
      if (dy < -20) {
        s.targetAimAngle = Math.atan2(dy, dx);
      }
      soundManager.playBowPull();
    };

    const handlePointerMove = (e: PointerEvent) => {
      const s = gameStateRef.current;
      if (!s.isDragging) return;

      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      const bowX = s.width * 0.5;
      const bowY = s.height * 0.84;
      const dx = clientX - bowX;
      const dy = clientY - bowY;

      if (dy < -15) {
        // Clamp aim angle between -165 deg and -15 deg (cannot aim down)
        const angle = Math.atan2(dy, dx);
        const clampedAngle = Math.max(-Math.PI * 0.92, Math.min(-Math.PI * 0.08, angle));
        s.targetAimAngle = clampedAngle;
      }
    };

    const handlePointerUp = () => {
      const s = gameStateRef.current;
      s.isDragging = false;
    };

    // Keyboard controls (Space / Enter to shoot, Left / Right to aim)
    const handleKeyDown = (e: KeyboardEvent) => {
      const { isPaused, canShoot } = propsRef.current;
      if (isPaused) return;

      const s = gameStateRef.current;
      if (e.code === 'Space' || e.code === 'Enter') {
        e.preventDefault();
        triggerShoot();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        s.targetAimAngle = Math.max(-Math.PI * 0.92, s.targetAimAngle - 0.04);
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        s.targetAimAngle = Math.min(-Math.PI * 0.08, s.targetAimAngle + 0.04);
      }
    };

    container.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      container.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [triggerShoot]);

  // Main 60FPS Game Loop
  useEffect(() => {
    let animId: number;

    const loop = (timestamp: number) => {
      animId = requestAnimationFrame(loop);

      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const s = gameStateRef.current;
      const { level, bow, arrowSkin, isPaused, combo, highGraphics, onHitResult } = propsRef.current;

      if (isPaused) return;

      // Handle Slow Motion from perfect bullseye
      let dtScale = 1;
      if (s.slowMotionTimer > 0) {
        s.slowMotionTimer--;
        dtScale = 0.35;
      }

      // Smooth aim angle towards target angle + natural subtle breathing sway
      s.swayTime += 0.03 * (bow.perkType === 'steady_aim' ? 0.4 : 1);
      const sway = Math.sin(s.swayTime) * 0.015 * (bow.perkType === 'steady_aim' ? 0.3 : 1);
      s.aimAngle += (s.targetAimAngle + sway - s.aimAngle) * 0.18;

      // Bow pull recovery animation
      if (s.bowPull > 0) {
        s.bowPull = Math.max(0, s.bowPull - 0.1);
      }

      // Screen shake decay
      if (s.screenShake > 0) {
        s.screenShake = Math.max(0, s.screenShake - 0.8);
      }

      // Dynamic wind oscillation if variation enabled
      if (level.windVariation) {
        s.windTimer += 0.02;
        s.currentWind = level.windSpeed + Math.sin(s.windTimer) * 0.8;
      } else {
        s.currentWind = level.windSpeed;
      }

      // --- 1. UPDATE TARGET MOTION ---
      s.targetPhase += 0.03 * dtScale;
      const minX = s.width * 0.15;
      const maxX = s.width * 0.85;

      switch (level.movementType) {
        case 'static':
          s.targetX = s.width * 0.5;
          break;
        case 'horizontal':
        case 'pingpong':
          s.targetX += s.targetVx * dtScale;
          if (s.targetX > maxX) {
            s.targetX = maxX;
            s.targetVx = -Math.abs(s.targetVx);
          } else if (s.targetX < minX) {
            s.targetX = minX;
            s.targetVx = Math.abs(s.targetVx);
          }
          break;
        case 'sine':
          s.targetX += s.targetVx * dtScale;
          s.targetY = s.height * 0.22 + Math.sin(s.targetPhase * 2) * 18;
          if (s.targetX > maxX) {
            s.targetX = maxX;
            s.targetVx = -Math.abs(s.targetVx);
          } else if (s.targetX < minX) {
            s.targetX = minX;
            s.targetVx = Math.abs(s.targetVx);
          }
          break;
        case 'accelerated':
          // Moves faster through center, slower at sides
          const centerDist = Math.abs(s.targetX - s.width * 0.5) / (s.width * 0.35);
          const currentSpeed = (1.5 - centerDist * 0.8) * s.targetVx;
          s.targetX += currentSpeed * dtScale;
          if (s.targetX > maxX) {
            s.targetX = maxX;
            s.targetVx = -Math.abs(s.targetVx);
          } else if (s.targetX < minX) {
            s.targetX = minX;
            s.targetVx = Math.abs(s.targetVx);
          }
          break;
      }

      // Decay target jiggle
      if (s.targetJiggle > 0) {
        s.targetJiggle = Math.max(0, s.targetJiggle - 0.5);
      }

      // --- 2. UPDATE OBSTACLES ---
      s.obstacleStates.forEach((obs, idx) => {
        const obsDef = level.obstacles[idx];
        if (!obsDef) return;
        obs.x += obs.vx * dtScale;
        const oMin = s.width * (obsDef.xRatio - obsDef.range * 0.5);
        const oMax = s.width * (obsDef.xRatio + obsDef.range * 0.5);
        if (obs.x > oMax) {
          obs.x = oMax;
          obs.vx = -Math.abs(obs.vx);
        } else if (obs.x < oMin) {
          obs.x = oMin;
          obs.vx = Math.abs(obs.vx);
        }
      });

      // --- 3. UPDATE FLYING ARROW ---
      if (s.flyingArrow && s.flyingArrow.active) {
        const arr = s.flyingArrow;

        // Apply wind physics (reduced if ice bow equipped)
        const windDriftFactor = bow.perkType === 'wind_resist' ? 0.05 : 0.12;
        arr.vx += s.currentWind * windDriftFactor * dtScale;

        // Move arrow
        arr.x += arr.vx * dtScale;
        arr.y += arr.vy * dtScale;
        arr.angle = Math.atan2(arr.vy, arr.vx);

        // Record trail
        arr.trail.unshift({ x: arr.x, y: arr.y, alpha: 1.0 });
        if (arr.trail.length > (highGraphics ? 12 : 6)) {
          arr.trail.pop();
        }

        // Particle sparks in flight for special arrows
        if (highGraphics && Math.random() < 0.4) {
          s.particles.push({
            x: arr.x,
            y: arr.y,
            vx: (Math.random() - 0.5) * 1.5,
            vy: (Math.random() - 0.5) * 1.5,
            color: arrowSkin.trailColor,
            life: 0,
            maxLife: 15,
            size: Math.random() * 3 + 1,
            type: arrowSkin.particleType,
          });
        }

        // A. Check Collision with Obstacles
        let hitObstacle = false;
        for (const obs of s.obstacleStates) {
          const left = obs.x - obs.width * 0.5;
          const right = obs.x + obs.width * 0.5;
          const top = obs.y - obs.height * 0.5;
          const bottom = obs.y + obs.height * 0.5;

          if (arr.x >= left && arr.x <= right && arr.y >= top && arr.y <= bottom) {
            hitObstacle = true;
            arr.active = false;
            s.flyingArrow = null;

            soundManager.playObstacleHit();
            s.screenShake = 6;

            // Wood splinter particles
            for (let p = 0; p < (highGraphics ? 20 : 10); p++) {
              s.particles.push({
                x: arr.x,
                y: arr.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                color: '#8b5a2b',
                life: 0,
                maxLife: 25,
                size: Math.random() * 4 + 2,
                type: 'wood',
              });
            }

            s.floatingTexts.push({
              id: `text_${Date.now()}`,
              text: 'BLOCKED!',
              subtext: 'Hit Shield',
              x: arr.x,
              y: arr.y - 15,
              color: '#ef4444',
              scale: 1.2,
              opacity: 1,
              vy: -1.2,
            });

            onHitResult({
              zone: 'obstacle',
              score: 0,
              coinsEarned: 0,
              accuracy: 0,
              distanceToCenter: 999,
              hitX: arr.x,
              hitY: arr.y,
              isBullseye: false,
              isPerfect: false,
            });
            break;
          }
        }

        // B. Check Collision with Target
        if (!hitObstacle) {
          // Check if arrow has reached target depth (y <= targetY + targetRadius)
          const targetR = level.targetRadius;
          const dist = Math.hypot(arr.x - s.targetX, arr.y - s.targetY);

          if (arr.y <= s.targetY + targetR * 0.6 && arr.y >= s.targetY - targetR) {
            // Check if within circular target bounds
            if (dist <= targetR) {
              arr.active = false;
              s.flyingArrow = null;
              s.targetJiggle = 8;

              // Store stuck arrow relative to target
              s.stuckArrows.push({
                relX: arr.x - s.targetX,
                relY: arr.y - s.targetY,
                angle: arr.angle,
                skinId: arrowSkin.id,
              });

              // Determine Hit Zone & Score
              const ratio = dist / targetR;
              let zone: HitResult['zone'] = 'outer';
              let baseScore = 10;
              let coins = 2;
              let isBullseye = false;
              let isPerfect = false;

              if (ratio <= 0.09) {
                // Perfect Bullseye dead center
                zone = 'perfect';
                baseScore = 200;
                coins = 20;
                isBullseye = true;
                isPerfect = true;
                s.slowMotionTimer = 16;
                s.screenShake = 14;
                soundManager.playPerfectHit();
              } else if (ratio <= 0.25) {
                // Yellow ring Bullseye
                zone = 'yellow';
                baseScore = 100;
                coins = 10;
                isBullseye = true;
                s.screenShake = 8;
                soundManager.playBullseyeHit();
              } else if (ratio <= 0.50) {
                // Red ring
                zone = 'red';
                baseScore = 50;
                coins = 5;
                s.screenShake = 4;
                soundManager.playTargetHit();
              } else if (ratio <= 0.75) {
                // Blue ring
                zone = 'blue';
                baseScore = 25;
                coins = 3;
                s.screenShake = 3;
                soundManager.playTargetHit();
              } else {
                // Outer ring
                zone = 'outer';
                baseScore = 10;
                coins = 2;
                s.screenShake = 2;
                soundManager.playTargetHit();
              }

              // Apply Bow perks (score bonus, royal extra coins)
              let scoreMultiplier = 1.0;
              if (bow.perkType === 'score_bonus' || bow.perkType === 'fire_burst' || bow.perkType === 'extra_coins') {
                scoreMultiplier += bow.perkValue;
              }
              // Combo multiplier: combo x2 = +20%, x3 = +40%, etc.
              const comboBonus = 1 + Math.min(combo * 0.15, 2.0);
              const finalScore = Math.round(baseScore * scoreMultiplier * comboBonus);

              if (bow.perkType === 'extra_coins') {
                coins = Math.round(coins * 1.3);
              }

              const accuracy = Math.round(Math.max(0, 100 - ratio * 100));

              // Particles on hit
              const particleCount = isPerfect ? (highGraphics ? 45 : 20) : isBullseye ? (highGraphics ? 25 : 12) : 10;
              const particleColor = isPerfect ? '#fef08a' : isBullseye ? '#fbbf24' : zone === 'red' ? '#ef4444' : zone === 'blue' ? '#38bdf8' : '#e2e8f0';

              for (let p = 0; p < particleCount; p++) {
                const speed = Math.random() * (isPerfect ? 9 : 5) + 1;
                const angle = Math.random() * Math.PI * 2;
                s.particles.push({
                  x: arr.x,
                  y: arr.y,
                  vx: Math.cos(angle) * speed,
                  vy: Math.sin(angle) * speed,
                  color: particleColor,
                  life: 0,
                  maxLife: Math.random() * 20 + 20,
                  size: Math.random() * (isPerfect ? 5 : 3) + 2,
                  type: isPerfect ? 'gold' : isBullseye ? 'star' : 'spark',
                });
              }

              // Floating Score / Combo Banner
              const bannerText = isPerfect ? 'PERFECT! +200' : isBullseye ? 'BULLSEYE! +100' : `+${finalScore}`;
              const subtext = combo > 0 ? `🔥 COMBO x${combo + 1}` : undefined;

              s.floatingTexts.push({
                id: `txt_${Date.now()}`,
                text: bannerText,
                subtext,
                x: arr.x,
                y: arr.y - 20,
                color: isPerfect ? '#fef08a' : isBullseye ? '#f59e0b' : '#38bdf8',
                scale: isPerfect ? 1.4 : isBullseye ? 1.2 : 1.0,
                opacity: 1,
                vy: -1.4,
              });

              onHitResult({
                zone,
                score: finalScore,
                coinsEarned: coins,
                accuracy,
                distanceToCenter: dist,
                hitX: arr.x,
                hitY: arr.y,
                isBullseye,
                isPerfect,
              });
            } else if (arr.y < s.targetY - targetR) {
              // Arrow flew completely above/past the target = MISS
              arr.active = false;
              s.flyingArrow = null;
              soundManager.playMiss();

              s.floatingTexts.push({
                id: `txt_${Date.now()}`,
                text: 'MISS',
                x: arr.x,
                y: Math.max(40, arr.y),
                color: '#94a3b8',
                scale: 1.0,
                opacity: 1,
                vy: -1.0,
              });

              onHitResult({
                zone: 'miss',
                score: 0,
                coinsEarned: 0,
                accuracy: 0,
                distanceToCenter: dist,
                hitX: arr.x,
                hitY: arr.y,
                isBullseye: false,
                isPerfect: false,
              });
            }
          }
        }
      }

      // --- 4. UPDATE PARTICLES & FLOATING TEXT ---
      s.particles.forEach((p) => {
        p.x += p.vx * dtScale;
        p.y += p.vy * dtScale;
        p.vy += 0.15 * dtScale; // gravity
        p.life += dtScale;
      });
      s.particles = s.particles.filter((p) => p.life < p.maxLife);

      s.floatingTexts.forEach((t) => {
        t.y += t.vy * dtScale;
        t.opacity -= 0.02 * dtScale;
      });
      s.floatingTexts = s.floatingTexts.filter((t) => t.opacity > 0);

      // --- 5. RENDER CANVAS SCENE ---
      ctx.save();
      ctx.scale(s.dpr, s.dpr);

      // Apply screen shake
      if (s.screenShake > 0) {
        const shakeX = (Math.random() - 0.5) * s.screenShake;
        const shakeY = (Math.random() - 0.5) * s.screenShake;
        ctx.translate(shakeX, shakeY);
      }

      // A. Background Sky & Deep Forest Atmosphere
      const bgGrad = ctx.createLinearGradient(0, 0, 0, s.height);
      bgGrad.addColorStop(0, '#0a1711');
      bgGrad.addColorStop(0.45, '#12261c');
      bgGrad.addColorStop(0.7, '#1b3829');
      bgGrad.addColorStop(1, '#0c1a13');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, s.width, s.height);

      // Distant mountain mist & pine trees
      ctx.fillStyle = 'rgba(10, 25, 18, 0.65)';
      ctx.beginPath();
      ctx.moveTo(0, s.height * 0.35);
      ctx.bezierCurveTo(s.width * 0.3, s.height * 0.3, s.width * 0.7, s.height * 0.4, s.width, s.height * 0.33);
      ctx.lineTo(s.width, s.height);
      ctx.lineTo(0, s.height);
      ctx.fill();

      // Range grass ground
      const groundGrad = ctx.createLinearGradient(0, s.height * 0.45, 0, s.height);
      groundGrad.addColorStop(0, '#12261a');
      groundGrad.addColorStop(1, '#09140e');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, s.height * 0.45, s.width, s.height * 0.55);

      // Shooting Lane Boundary Markers
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.15)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.moveTo(s.width * 0.2, s.height * 0.45);
      ctx.lineTo(s.width * 0.05, s.height);
      ctx.moveTo(s.width * 0.8, s.height * 0.45);
      ctx.lineTo(s.width * 0.95, s.height);
      ctx.stroke();
      ctx.setLineDash([]);

      // Distance Line Rings on Ground (10m, 20m, 30m)
      [0.55, 0.68, 0.8].forEach((ratio, idx) => {
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(s.width * 0.5, s.height * ratio, s.width * (0.35 + idx * 0.15), 18, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.25)';
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`${(3 - idx) * 10}m`, s.width * 0.15, s.height * ratio + 3);
      });

      // B. Archery Wind Pennants / Flags
      const flagX = s.width * 0.12;
      const flagY = s.height * 0.22;
      // Wooden Pole
      ctx.strokeStyle = '#5c3a1e';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(flagX, flagY - 35);
      ctx.lineTo(flagX, flagY + 45);
      ctx.stroke();

      // Flag flapping with wind
      const windAngle = s.currentWind * 0.35;
      const flagFlap = Math.sin(timestamp * 0.008) * 4;
      const flagTipX = flagX + Math.sin(windAngle) * 26 + (s.currentWind >= 0 ? 18 : -18);
      const flagTipY = flagY - 26 + flagFlap;

      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.moveTo(flagX, flagY - 32);
      ctx.lineTo(flagTipX, flagTipY);
      ctx.lineTo(flagX, flagY - 14);
      ctx.closePath();
      ctx.fill();

      // C. Draw Target Easel (Wooden Legs behind Target)
      const targetR = level.targetRadius;
      const jiggleX = (Math.sin(s.targetJiggle * 3) * s.targetJiggle * 0.8);
      const tX = s.targetX + jiggleX;
      const tY = s.targetY;

      // Easel Tripod
      ctx.strokeStyle = '#5c3a1e';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.moveTo(tX, tY);
      ctx.lineTo(tX - targetR * 0.9, tY + targetR * 1.5);
      ctx.moveTo(tX, tY);
      ctx.lineTo(tX + targetR * 0.9, tY + targetR * 1.5);
      ctx.moveTo(tX, tY);
      ctx.lineTo(tX, tY + targetR * 1.4);
      ctx.stroke();

      // Target Shadow on Ground
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(tX, tY + targetR * 1.5, targetR * 0.9, 10, 0, 0, Math.PI * 2);
      ctx.fill();

      // Straw Boss Backing
      ctx.fillStyle = '#78522e';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR + 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#3e2712';
      ctx.lineWidth = 3;
      ctx.stroke();

      // D. Draw Archery Target Rings
      // 1. White Outer Ring (+10)
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // 2. Black Ring Division
      ctx.strokeStyle = '#cbd5e1';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.88, 0, Math.PI * 2);
      ctx.stroke();

      // 3. Blue Ring (+25)
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.75, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#0369a1';
      ctx.stroke();

      ctx.strokeStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.62, 0, Math.PI * 2);
      ctx.stroke();

      // 4. Red Ring (+50)
      ctx.fillStyle = '#dc2626';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.50, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#b91c1c';
      ctx.stroke();

      ctx.strokeStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.37, 0, Math.PI * 2);
      ctx.stroke();

      // 5. Yellow Bullseye Ring (+100)
      const bullGrad = ctx.createRadialGradient(tX, tY, 0, tX, tY, targetR * 0.25);
      bullGrad.addColorStop(0, '#fef08a');
      bullGrad.addColorStop(1, '#eab308');
      ctx.fillStyle = bullGrad;
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.25, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#ca8a04';
      ctx.stroke();

      // 6. Perfect Center Crosshair & Inner Bullseye (+200)
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(tX, tY, targetR * 0.08, 0, Math.PI * 2);
      ctx.fill();

      // Center crosshair
      ctx.strokeStyle = '#ca8a04';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(tX - 4, tY);
      ctx.lineTo(tX + 4, tY);
      ctx.moveTo(tX, tY - 4);
      ctx.lineTo(tX, tY + 4);
      ctx.stroke();

      // E. Draw Stuck Arrows in Target
      s.stuckArrows.forEach((arr) => {
        const arrowX = tX + arr.relX;
        const arrowY = tY + arr.relY;
        const skin = ARROW_SKINS.find((sk) => sk.id === arr.skinId) || ARROW_SKINS[0];

        ctx.save();
        ctx.translate(arrowX, arrowY);
        ctx.rotate(arr.angle);

        // Stuck arrow shaft protruding backward
        ctx.strokeStyle = skin.shaftColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-24, 0);
        ctx.stroke();

        // Nock & Fletching
        ctx.fillStyle = skin.fletchColor;
        ctx.beginPath();
        ctx.moveTo(-20, -4);
        ctx.lineTo(-25, 0);
        ctx.lineTo(-20, 4);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      });

      // F. Draw Obstacles (Moving Shields/Barriers)
      s.obstacleStates.forEach((obs) => {
        ctx.save();
        ctx.translate(obs.x, obs.y);

        // Wooden Shield Body
        const shieldGrad = ctx.createLinearGradient(-obs.width * 0.5, 0, obs.width * 0.5, 0);
        shieldGrad.addColorStop(0, '#5c3a1e');
        shieldGrad.addColorStop(0.5, '#8b5a2b');
        shieldGrad.addColorStop(1, '#5c3a1e');
        ctx.fillStyle = shieldGrad;
        ctx.beginPath();
        ctx.roundRect(-obs.width * 0.5, -obs.height * 0.5, obs.width, obs.height, 6);
        ctx.fill();

        // Metal Rim & Rivets
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Metal Boss in Center
        ctx.fillStyle = '#cbd5e1';
        ctx.beginPath();
        ctx.arc(0, 0, 5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      });

      // G. Draw Aim Trajectory Indicator Dots
      if (!s.flyingArrow && propsRef.current.arrowsRemaining > 0 && propsRef.current.canShoot) {
        const bowOriginX = s.width * 0.5;
        const bowOriginY = s.height * 0.84;

        ctx.save();
        const dotCount = 14;
        const speed = 24;
        let simX = bowOriginX;
        let simY = bowOriginY;
        let simVx = Math.cos(s.aimAngle) * speed;
        let simVy = Math.sin(s.aimAngle) * speed;
        const windDriftFactor = bow.perkType === 'wind_resist' ? 0.05 : 0.12;

        for (let i = 1; i <= dotCount; i++) {
          simVx += s.currentWind * windDriftFactor * 0.7;
          simX += simVx * 0.7;
          simY += simVy * 0.7;

          const progress = i / dotCount;
          const alpha = (1 - progress) * 0.65;
          const radius = Math.max(1.5, 3.5 * (1 - progress * 0.5));

          ctx.fillStyle = `rgba(251, 191, 36, ${alpha})`;
          ctx.beginPath();
          ctx.arc(simX, simY, radius, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // H. Draw Flying Arrow
      if (s.flyingArrow && s.flyingArrow.active) {
        const arr = s.flyingArrow;
        const skin = ARROW_SKINS.find((sk) => sk.id === arr.skinId) || ARROW_SKINS[0];

        // Draw Motion Trail
        if (arr.trail.length > 1) {
          ctx.save();
          for (let i = 0; i < arr.trail.length - 1; i++) {
            const p1 = arr.trail[i];
            const p2 = arr.trail[i + 1];
            const trailAlpha = (1 - i / arr.trail.length) * 0.7;
            ctx.strokeStyle = skin.trailColor;
            ctx.lineWidth = Math.max(1, 4 * (1 - i / arr.trail.length));
            ctx.globalAlpha = trailAlpha;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
          ctx.restore();
        }

        // Draw Arrow
        ctx.save();
        ctx.translate(arr.x, arr.y);
        ctx.rotate(arr.angle);

        // Arrow Shaft
        ctx.strokeStyle = skin.shaftColor;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(-32, 0);
        ctx.lineTo(8, 0);
        ctx.stroke();

        // Arrowhead (Triangle)
        ctx.fillStyle = skin.headColor;
        ctx.beginPath();
        ctx.moveTo(14, 0);
        ctx.lineTo(6, -4);
        ctx.lineTo(6, 4);
        ctx.closePath();
        ctx.fill();

        // Fletching Feathers
        ctx.fillStyle = skin.fletchColor;
        ctx.beginPath();
        ctx.moveTo(-24, -5);
        ctx.lineTo(-32, 0);
        ctx.lineTo(-24, 5);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      }

      // I. Draw Player Bow at Bottom Center
      const bowX = s.width * 0.5;
      const bowY = s.height * 0.84;

      ctx.save();
      ctx.translate(bowX, bowY);
      ctx.rotate(s.aimAngle + Math.PI / 2); // Rotate bow with aim

      // Bow Arc (Limb)
      ctx.strokeStyle = bow.bodyColor;
      ctx.lineWidth = 8;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.arc(0, 0, 48, Math.PI * 0.8, Math.PI * 0.2, true);
      ctx.stroke();

      // Bow Accent Wrap / Grip
      ctx.strokeStyle = bow.accentColor;
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.arc(0, 0, 48, Math.PI * 0.56, Math.PI * 0.44, true);
      ctx.stroke();

      // Bowstring
      const bowStringY = 32 + s.bowPull * 18;
      const tipLeftX = Math.cos(Math.PI * 0.8) * 48;
      const tipLeftY = Math.sin(Math.PI * 0.8) * 48;
      const tipRightX = Math.cos(Math.PI * 0.2) * 48;
      const tipRightY = Math.sin(Math.PI * 0.2) * 48;

      ctx.strokeStyle = bow.stringColor;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(tipLeftX, tipLeftY);
      ctx.lineTo(0, bowStringY);
      ctx.lineTo(tipRightX, tipRightY);
      ctx.stroke();

      // Nocked Arrow in Bow (if arrows remain and not currently in flight)
      if (propsRef.current.arrowsRemaining > 0 && !s.flyingArrow) {
        ctx.strokeStyle = arrowSkin.shaftColor;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(0, bowStringY);
        ctx.lineTo(0, -28);
        ctx.stroke();

        // Arrowhead
        ctx.fillStyle = arrowSkin.headColor;
        ctx.beginPath();
        ctx.moveTo(0, -34);
        ctx.lineTo(-4, -26);
        ctx.lineTo(4, -26);
        ctx.closePath();
        ctx.fill();

        // Fletching
        ctx.fillStyle = arrowSkin.fletchColor;
        ctx.beginPath();
        ctx.moveTo(-4, bowStringY - 4);
        ctx.lineTo(0, bowStringY);
        ctx.lineTo(4, bowStringY - 4);
        ctx.closePath();
        ctx.fill();
      }

      ctx.restore();

      // J. Draw Particles
      s.particles.forEach((p) => {
        const alpha = 1 - p.life / p.maxLife;
        ctx.fillStyle = p.color;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1.0;

      // K. Draw Floating Combat Text
      s.floatingTexts.forEach((t) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, t.opacity);
        ctx.textAlign = 'center';

        // Shadow outline
        ctx.font = `bold ${Math.round(18 * t.scale)}px sans-serif`;
        ctx.fillStyle = 'rgba(0, 0, 0, 0.85)';
        ctx.fillText(t.text, t.x, t.y + 2);

        ctx.fillStyle = t.color;
        ctx.fillText(t.text, t.x, t.y);

        if (t.subtext) {
          ctx.font = `bold ${Math.round(13 * t.scale)}px sans-serif`;
          ctx.fillStyle = '#f59e0b';
          ctx.fillText(t.subtext, t.x, t.y + 18);
        }
        ctx.restore();
      });

      ctx.restore();
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="relative w-full h-full overflow-hidden select-none touch-none cursor-crosshair"
      style={{ WebkitUserSelect: 'none' }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />
    </div>
  );
};
