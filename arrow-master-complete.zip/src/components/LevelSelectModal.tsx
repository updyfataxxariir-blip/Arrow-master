import React from 'react';
import { ArrowLeft, Lock, Star, Play } from 'lucide-react';
import { LevelConfig, UserSaveState } from '../types';
import { LEVELS } from '../game/levels';
import { soundManager } from '../audio/soundManager';

interface LevelSelectModalProps {
  saveState: UserSaveState;
  onSelectLevel: (level: LevelConfig) => void;
  onBack: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  saveState,
  onSelectLevel,
  onBack,
}) => {
  const totalStars = Object.values(saveState.levelStars).reduce((acc, s) => acc + s, 0);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b1711] text-slate-100 select-none">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-stone-800/80 bg-stone-950/70 backdrop-blur-md">
        <button
          id="level-select-back"
          onClick={() => {
            soundManager.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-stone-300 hover:text-white px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 active:scale-95 transition text-sm font-bold"
        >
          <ArrowLeft size={18} />
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black tracking-wide text-amber-300 uppercase">
            SELECT LEVEL
          </h2>
          <span className="text-xs text-stone-400 font-medium">50 Archery Stages</span>
        </div>

        <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-black text-amber-300">
          <Star size={14} className="fill-amber-400 text-amber-400" />
          <span>{totalStars} / 150</span>
        </div>
      </div>

      {/* Levels Grid */}
      <div className="flex-1 overflow-y-auto p-4 max-w-2xl mx-auto w-full">
        <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-6 gap-3 pb-8">
          {LEVELS.map((lvl) => {
            const isUnlocked = lvl.id <= saveState.highestUnlockedLevel;
            const stars = saveState.levelStars[lvl.id] || 0;
            const highScore = saveState.levelHighScores[lvl.id] || 0;

            return (
              <button
                key={lvl.id}
                id={`level-button-${lvl.id}`}
                disabled={!isUnlocked}
                onClick={() => {
                  if (isUnlocked) {
                    soundManager.playButtonClick();
                    onSelectLevel(lvl);
                  }
                }}
                className={`relative flex flex-col items-center justify-between p-3 rounded-2xl border transition-all duration-200 aspect-square ${
                  isUnlocked
                    ? 'bg-stone-900/90 border-amber-500/30 hover:border-amber-400 active:scale-95 shadow-md hover:shadow-amber-500/20 cursor-pointer'
                    : 'bg-stone-950/40 border-stone-800/40 opacity-40 cursor-not-allowed'
                }`}
              >
                {/* Level Number or Lock */}
                <div className="w-full flex items-center justify-between">
                  <span className="text-xs font-bold text-stone-400">
                    #{lvl.id}
                  </span>
                  {!isUnlocked ? (
                    <Lock size={12} className="text-stone-500" />
                  ) : stars > 0 ? (
                    <span className="text-[10px] font-bold text-emerald-400">✓</span>
                  ) : (
                    <Play size={10} className="text-amber-400 fill-amber-400" />
                  )}
                </div>

                <div className="my-auto text-lg sm:text-xl font-black text-white">
                  {lvl.id}
                </div>

                {/* Stars Indicator */}
                <div className="flex items-center gap-0.5">
                  {isUnlocked ? (
                    [1, 2, 3].map((starIdx) => (
                      <Star
                        key={starIdx}
                        size={11}
                        className={
                          starIdx <= stars
                            ? 'fill-amber-400 text-amber-400 drop-shadow'
                            : 'text-stone-700'
                        }
                      />
                    ))
                  ) : (
                    <span className="text-[10px] text-stone-600 font-bold">LOCKED</span>
                  )}
                </div>

                {/* Best Score preview if completed */}
                {highScore > 0 && (
                  <span className="text-[9px] text-stone-400 font-medium truncate w-full text-center">
                    {highScore} pts
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
