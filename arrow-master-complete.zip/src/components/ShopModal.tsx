import React, { useState } from 'react';
import { ArrowLeft, Check, Sparkles } from 'lucide-react';
import { UserSaveState } from '../types';
import { BOWS, ARROW_SKINS } from '../game/items';
import { soundManager } from '../audio/soundManager';

interface ShopModalProps {
  saveState: UserSaveState;
  onBuyBow: (bowId: string, price: number) => void;
  onEquipBow: (bowId: string) => void;
  onBuyArrow: (arrowId: string, price: number) => void;
  onEquipArrow: (arrowId: string) => void;
  onBack: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  saveState,
  onBuyBow,
  onEquipBow,
  onBuyArrow,
  onEquipArrow,
  onBack,
}) => {
  const [activeTab, setActiveTab] = useState<'bows' | 'arrows'>('bows');

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0b1711] text-slate-100 select-none">
      {/* Header Bar */}
      <div className="flex items-center justify-between p-4 border-b border-stone-800/80 bg-stone-950/80 backdrop-blur-md">
        <button
          id="shop-back-button"
          onClick={() => {
            soundManager.playButtonClick();
            onBack();
          }}
          className="flex items-center gap-1.5 text-stone-300 hover:text-white px-3 py-1.5 rounded-lg bg-stone-900 border border-stone-800 active:scale-95 transition text-sm font-bold"
        >
          <ArrowLeft size={18} />
          <span>Back</span>
        </button>

        <div className="text-center">
          <h2 className="text-lg font-black tracking-wide text-amber-300 uppercase">
            ARCHER'S ARMORY
          </h2>
          <span className="text-xs text-stone-400 font-medium">Bows & Enchanted Arrows</span>
        </div>

        {/* Currency Display */}
        <div className="flex items-center gap-1.5 bg-black/60 border border-amber-500/40 px-3.5 py-1.5 rounded-full shadow-lg">
          <span className="text-amber-400 text-sm font-bold">🪙</span>
          <span className="text-xs sm:text-sm font-black text-amber-300">
            {saveState.coins.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Navigation Tabs: Bows vs Arrows */}
      <div className="flex items-center justify-center p-3 bg-stone-950/40">
        <div className="flex p-1 bg-stone-900 rounded-xl border border-stone-800 w-full max-w-xs">
          <button
            id="tab-bows"
            onClick={() => {
              soundManager.playButtonClick();
              setActiveTab('bows');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition ${
              activeTab === 'bows'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            🏹 Bows ({BOWS.length})
          </button>
          <button
            id="tab-arrows"
            onClick={() => {
              soundManager.playButtonClick();
              setActiveTab('arrows');
            }}
            className={`flex-1 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition ${
              activeTab === 'arrows'
                ? 'bg-amber-500 text-stone-950 shadow-md'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            🎯 Arrows ({ARROW_SKINS.length})
          </button>
        </div>
      </div>

      {/* Catalogue Items List */}
      <div className="flex-1 overflow-y-auto p-4 max-w-2xl mx-auto w-full">
        {activeTab === 'bows' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-8">
            {BOWS.map((bow) => {
              const isUnlocked = saveState.unlockedBows.includes(bow.id);
              const isEquipped = saveState.selectedBow === bow.id;
              const canAfford = saveState.coins >= bow.price;

              return (
                <div
                  key={bow.id}
                  className={`flex flex-col justify-between p-4 rounded-2xl border transition-all ${
                    isEquipped
                      ? 'bg-gradient-to-b from-stone-900 to-amber-950/40 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                      : isUnlocked
                      ? 'bg-stone-900/80 border-stone-800'
                      : 'bg-stone-950/60 border-stone-800/80'
                  }`}
                >
                  {/* Item Top: Icon preview & details */}
                  <div className="flex items-start gap-3.5">
                    {/* SVG Canvas Visual Mini Preview */}
                    <div
                      className="w-14 h-14 rounded-xl flex items-center justify-center relative overflow-hidden shrink-0 border"
                      style={{
                        backgroundColor: '#111e17',
                        borderColor: bow.accentColor,
                        boxShadow: bow.glowColor ? `0 0 10px ${bow.glowColor}40` : undefined,
                      }}
                    >
                      {/* Stylized Bow Arc */}
                      <svg width="40" height="40" viewBox="0 0 40 40">
                        <path
                          d="M 12 6 Q 2 20 12 34"
                          fill="none"
                          stroke={bow.bodyColor}
                          strokeWidth="3.5"
                          strokeLinecap="round"
                        />
                        <line
                          x1="12"
                          y1="6"
                          x2="12"
                          y2="34"
                          stroke={bow.stringColor}
                          strokeWidth="1.2"
                        />
                        {/* Grip */}
                        <path
                          d="M 6 18 Q 4 20 6 22"
                          fill="none"
                          stroke={bow.accentColor}
                          strokeWidth="4"
                        />
                      </svg>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <h3 className="text-sm font-black text-white truncate">{bow.name}</h3>
                        {isEquipped && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-400/30">
                            EQUIPPED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-400 line-clamp-2 mt-0.5">
                        {bow.description}
                      </p>
                      <div className="flex items-center gap-1 mt-1 text-[11px] font-bold text-amber-300">
                        <Sparkles size={12} className="text-amber-400" />
                        <span>{bow.perk}</span>
                      </div>
                    </div>
                  </div>

                  {/* Item Bottom: Action Button */}
                  <div className="mt-3 pt-2.5 border-t border-stone-800/60 flex items-center justify-between">
                    <div>
                      {!isUnlocked && (
                        <div className="flex items-center gap-1 text-xs font-black text-amber-300">
                          <span>🪙</span>
                          <span>{bow.price.toLocaleString()}</span>
                        </div>
                      )}
                    </div>

                    {isEquipped ? (
                      <button
                        disabled
                        className="px-4 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center gap-1 cursor-default"
                      >
                        <Check size={14} /> Active
                      </button>
                    ) : isUnlocked ? (
                      <button
                        id={`equip-bow-${bow.id}`}
                        onClick={() => {
                          soundManager.playButtonClick();
                          onEquipBow(bow.id);
                        }}
                        className="px-4 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-100 border border-stone-700 text-xs font-bold active:scale-95 transition"
                      >
                        Equip
                      </button>
                    ) : (
                      <button
                        id={`buy-bow-${bow.id}`}
                        disabled={!canAfford}
                        onClick={() => {
                          if (canAfford) {
                            soundManager.playUnlock();
                            onBuyBow(bow.id, bow.price);
                          }
                        }}
                        className={`px-4 py-1.5 rounded-xl text-xs font-black tracking-wide uppercase transition active:scale-95 ${
                          canAfford
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 hover:brightness-110 shadow-md cursor-pointer'
                            : 'bg-stone-800 text-stone-500 border border-stone-700/50 cursor-not-allowed'
                        }`}
                      >
                        Buy for {bow.price} 🪙
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-8">
            {ARROW_SKINS.map((arr) => {
              const isUnlocked = saveState.unlockedArrows.includes(arr.id);
              const isEquipped = saveState.selectedArrow === arr.id;
              const canAfford = saveState.coins >= arr.price;

              return (
                <div
                  key={arr.id}
                  className={`flex flex-col justify-between p-4 rounded-2xl border transition-all ${
                    isEquipped
                      ? 'bg-gradient-to-b from-stone-900 to-amber-950/40 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.2)]'
                      : isUnlocked
                      ? 'bg-stone-900/80 border-stone-800'
                      : 'bg-stone-950/60 border-stone-800/80'
                  }`}
                >
                  <div className="flex items-start gap-3.5">
                    {/* SVG Canvas Arrow Visual Preview */}
                    <div
                      className="w-14 h-14 rounded-xl flex items-center justify-center relative overflow-hidden shrink-0 border"
                      style={{
                        backgroundColor: '#111e17',
                        borderColor: arr.shaftColor,
                        boxShadow: arr.glowColor ? `0 0 10px ${arr.glowColor}40` : undefined,
                      }}
                    >
                      <svg width="40" height="40" viewBox="0 0 40 40">
                        {/* Diagonal arrow */}
                        <line
                          x1="8"
                          y1="32"
                          x2="28"
                          y2="12"
                          stroke={arr.shaftColor}
                          strokeWidth="2.5"
                        />
                        {/* Tip */}
                        <polygon
                          points="32,8 26,10 30,14"
                          fill={arr.headColor}
                        />
                        {/* Fletch */}
                        <polygon
                          points="8,32 12,31 7,27"
                          fill={arr.fletchColor}
                        />
                      </svg>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <h3 className="text-sm font-black text-white truncate">{arr.name}</h3>
                        {isEquipped && (
                          <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-400/30">
                            EQUIPPED
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-400 line-clamp-2 mt-0.5">
                        {arr.description}
                      </p>
                      <div className="flex items-center gap-1 mt-1 text-[11px] font-bold text-sky-300">
                        <Sparkles size={12} className="text-sky-400" />
                        <span className="capitalize">{arr.particleType} Trail FX</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-stone-800/60 flex items-center justify-between">
                    <div>
                      {!isUnlocked && (
                        <div className="flex items-center gap-1 text-xs font-black text-amber-300">
                          <span>🪙</span>
                          <span>{arr.price.toLocaleString()}</span>
                        </div>
                      )}
                    </div>

                    {isEquipped ? (
                      <button
                        disabled
                        className="px-4 py-1.5 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-400/40 text-xs font-bold flex items-center gap-1 cursor-default"
                      >
                        <Check size={14} /> Active
                      </button>
                    ) : isUnlocked ? (
                      <button
                        id={`equip-arrow-${arr.id}`}
                        onClick={() => {
                          soundManager.playButtonClick();
                          onEquipArrow(arr.id);
                        }}
                        className="px-4 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-100 border border-stone-700 text-xs font-bold active:scale-95 transition"
                      >
                        Equip
                      </button>
                    ) : (
                      <button
                        id={`buy-arrow-${arr.id}`}
                        disabled={!canAfford}
                        onClick={() => {
                          if (canAfford) {
                            soundManager.playUnlock();
                            onBuyArrow(arr.id, arr.price);
                          }
                        }}
                        className={`px-4 py-1.5 rounded-xl text-xs font-black tracking-wide uppercase transition active:scale-95 ${
                          canAfford
                            ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 hover:brightness-110 shadow-md cursor-pointer'
                            : 'bg-stone-800 text-stone-500 border border-stone-700/50 cursor-not-allowed'
                        }`}
                      >
                        Buy for {arr.price} 🪙
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
