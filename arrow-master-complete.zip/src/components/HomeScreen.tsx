import React from 'react';
import { Play, Grid, ShoppingBag, Award, Settings, Gift, Sparkles, Download } from 'lucide-react';
import { UserSaveState } from '../types';
import { soundManager } from '../audio/soundManager';

interface HomeScreenProps {
  saveState: UserSaveState;
  onPlay: () => void;
  onOpenLevels: () => void;
  onOpenShop: () => void;
  onOpenAchievements: () => void;
  onOpenSettings: () => void;
  onClaimDailyReward: () => void;
  canClaimDailyReward: boolean;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  saveState,
  onPlay,
  onOpenLevels,
  onOpenShop,
  onOpenAchievements,
  onOpenSettings,
  onClaimDailyReward,
  canClaimDailyReward,
}) => {
  // Calculate total stars earned
  const totalStars = Object.values(saveState.levelStars).reduce((acc, s) => acc + s, 0);
  const bestScore = Math.max(0, ...Object.values(saveState.levelHighScores));

  return (
    <div className="relative w-full h-full flex flex-col justify-between items-center p-4 sm:p-6 overflow-y-auto forest-gradient text-slate-100 select-none">
      {/* Subtle background decorative mist & target rings */}
      <div className="absolute inset-0 pointer-events-none opacity-10 overflow-hidden flex items-center justify-center">
        <div className="w-[500px] h-[500px] rounded-full border-[30px] border-amber-500 animate-pulse" />
        <div className="absolute w-[360px] h-[360px] rounded-full border-[25px] border-red-500" />
        <div className="absolute w-[220px] h-[220px] rounded-full border-[20px] border-sky-500" />
      </div>

      {/* Top Bar: Currency & Stats & Download */}
      <div className="w-full max-w-md flex items-center justify-between z-10 pt-1 gap-2">
        {/* Daily Reward Button */}
        <button
          id="daily-reward-button"
          onClick={() => {
            soundManager.playButtonClick();
            onClaimDailyReward();
          }}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-bold transition shadow-lg ${
            canClaimDailyReward
              ? 'bg-gradient-to-r from-amber-600 to-yellow-500 text-stone-950 border-amber-300 animate-bounce'
              : 'bg-stone-900/70 text-stone-400 border-stone-700/50 cursor-default'
          }`}
        >
          <Gift size={14} className={canClaimDailyReward ? 'text-stone-950' : 'text-stone-400'} />
          <span>{canClaimDailyReward ? 'Claim 🎁 +150' : 'Daily Claimed ✓'}</span>
        </button>

        {/* Right side: ZIP Download & Treasury Coins */}
        <div className="flex items-center gap-2">
          <a
            id="home-download-zip-button"
            href="/arrow-master-complete.zip"
            download="arrow-master-complete.zip"
            onClick={() => soundManager.playButtonClick()}
            className="flex items-center gap-1 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 px-2.5 py-1.5 rounded-full shadow-lg text-xs font-black transition active:scale-95 cursor-pointer"
            title="Download complete project ZIP (TypeScript, React, C++, HTML, Assets)"
          >
            <Download size={13} />
            <span>ZIP</span>
          </a>

          {/* Treasury Coins */}
          <div className="flex items-center gap-1.5 bg-stone-950/70 border border-amber-500/30 px-3 py-1.5 rounded-full shadow-lg">
            <span className="text-amber-400 text-sm font-bold">🪙</span>
            <span className="text-xs sm:text-sm font-black text-amber-300 tracking-wide">
              {saveState.coins.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Hero Logo & Branding */}
      <div className="flex flex-col items-center text-center my-auto z-10">
        {/* Animated Target & Arrow Icon */}
        <div className="relative w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center mb-3">
          <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-500/20 to-emerald-500/20 blur-xl animate-pulse" />
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-full border-4 border-amber-400/80 bg-stone-950/80 flex items-center justify-center shadow-[0_0_25px_rgba(245,158,11,0.3)]">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full border-4 border-red-500/80 bg-stone-900 flex items-center justify-center">
              <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full border-4 border-yellow-400 bg-amber-500 flex items-center justify-center">
                <span className="text-xl sm:text-2xl drop-shadow">🎯</span>
              </div>
            </div>
          </div>
          <div className="absolute -top-1 -right-1 text-xl sm:text-2xl animate-spin" style={{ animationDuration: '10s' }}>
            <Sparkles className="text-amber-300" size={20} />
          </div>
        </div>

        {/* Main Title */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white flex items-center gap-2 drop-shadow-[0_4px_10px_rgba(0,0,0,0.8)]">
          <span>🏹</span>
          <span className="bg-gradient-to-b from-amber-200 via-amber-400 to-amber-600 bg-clip-text text-transparent">
            ARROW MASTER
          </span>
        </h1>
        <p className="text-xs sm:text-sm font-bold tracking-widest text-emerald-400 uppercase mt-1">
          Master Your Aim
        </p>

        {/* Primary Play Button */}
        <div className="w-full max-w-xs mt-6">
          <button
            id="play-button"
            onClick={() => {
              soundManager.playButtonClick();
              onPlay();
            }}
            className="w-full h-16 rounded-2xl bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 text-stone-950 font-black text-xl tracking-wider uppercase border-2 border-yellow-200 shadow-[0_10px_30px_rgba(245,158,11,0.4)] hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            <Play size={24} fill="currentColor" />
            <span>PLAY NOW</span>
          </button>
        </div>
      </div>

      {/* Menu Actions Grid */}
      <div className="w-full max-w-md flex flex-col gap-3 z-10 mb-2">
        <div className="grid grid-cols-4 gap-2">
          {/* Levels */}
          <button
            id="levels-menu-button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenLevels();
            }}
            className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 active:scale-95 transition shadow-md"
          >
            <Grid className="text-amber-400 mb-1" size={20} />
            <span className="text-[11px] font-bold text-stone-300">Levels</span>
          </button>

          {/* Shop */}
          <button
            id="shop-menu-button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenShop();
            }}
            className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 active:scale-95 transition shadow-md"
          >
            <ShoppingBag className="text-amber-400 mb-1" size={20} />
            <span className="text-[11px] font-bold text-stone-300">Shop</span>
          </button>

          {/* Achievements */}
          <button
            id="achievements-menu-button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenAchievements();
            }}
            className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 active:scale-95 transition shadow-md"
          >
            <Award className="text-amber-400 mb-1" size={20} />
            <span className="text-[11px] font-bold text-stone-300">Badges</span>
          </button>

          {/* Settings */}
          <button
            id="settings-menu-button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenSettings();
            }}
            className="flex flex-col items-center justify-center p-2.5 rounded-xl bg-stone-900/80 border border-stone-800 hover:border-amber-500/40 active:scale-95 transition shadow-md"
          >
            <Settings className="text-amber-400 mb-1" size={20} />
            <span className="text-[11px] font-bold text-stone-300">Settings</span>
          </button>
        </div>

        {/* Player Stats Footer Bar */}
        <div className="w-full bg-stone-950/60 backdrop-blur-md rounded-xl p-3 border border-stone-800/80 flex items-center justify-around text-center">
          <div>
            <div className="text-[10px] uppercase font-bold text-stone-400">Stars</div>
            <div className="text-sm font-extrabold text-amber-400 flex items-center justify-center gap-0.5">
              <span>⭐</span> {totalStars} / 150
            </div>
          </div>
          <div className="w-[1px] h-6 bg-stone-800" />
          <div>
            <div className="text-[10px] uppercase font-bold text-stone-400">Best Score</div>
            <div className="text-sm font-extrabold text-emerald-400">
              {bestScore.toLocaleString()}
            </div>
          </div>
          <div className="w-[1px] h-6 bg-stone-800" />
          <div>
            <div className="text-[10px] uppercase font-bold text-stone-400">Highest Level</div>
            <div className="text-sm font-extrabold text-sky-400">
              {saveState.highestUnlockedLevel} / 50
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
