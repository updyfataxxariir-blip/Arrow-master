import React from 'react';
import { Play, RotateCcw, Settings, Home } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface PauseModalProps {
  levelNumber: number;
  onResume: () => void;
  onRestart: () => void;
  onOpenSettings: () => void;
  onHome: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  levelNumber,
  onResume,
  onRestart,
  onOpenSettings,
  onHome,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-xs rounded-3xl bg-stone-900 border border-amber-500/30 p-6 shadow-2xl text-center space-y-4">
        {/* Title */}
        <div className="space-y-1">
          <div className="text-xs uppercase tracking-widest text-amber-400 font-extrabold">
            Level {levelNumber}
          </div>
          <h2 className="text-2xl font-black text-white tracking-wider uppercase">
            GAME PAUSED
          </h2>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2.5 pt-2">
          {/* Resume */}
          <button
            id="pause-resume-button"
            onClick={() => {
              soundManager.playButtonClick();
              onResume();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-black text-base uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={18} fill="currentColor" />
            <span>Resume</span>
          </button>

          {/* Restart */}
          <button
            id="pause-restart-button"
            onClick={() => {
              soundManager.playButtonClick();
              onRestart();
            }}
            className="w-full py-3 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-sm uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={16} />
            <span>Restart Level</span>
          </button>

          {/* Settings */}
          <button
            id="pause-settings-button"
            onClick={() => {
              soundManager.playButtonClick();
              onOpenSettings();
            }}
            className="w-full py-3 rounded-2xl bg-stone-800 hover:bg-stone-700 text-stone-200 font-bold text-sm uppercase tracking-wider border border-stone-700 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Settings size={16} />
            <span>Settings</span>
          </button>

          {/* Home */}
          <button
            id="pause-home-button"
            onClick={() => {
              soundManager.playButtonClick();
              onHome();
            }}
            className="w-full py-3 rounded-2xl bg-stone-950/80 hover:bg-stone-800 text-stone-400 font-bold text-sm uppercase tracking-wider border border-stone-800 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home size={16} />
            <span>Quit to Home</span>
          </button>
        </div>
      </div>
    </div>
  );
};
