import React from 'react';
import { Target, MoveHorizontal, Wind, Award, Check } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface TutorialModalProps {
  onClose: () => void;
}

export const TutorialModal: React.FC<TutorialModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-stone-900 border border-amber-500/30 p-5 sm:p-6 shadow-2xl text-center space-y-4">
        {/* Title */}
        <div className="space-y-1">
          <div className="text-xs uppercase tracking-widest text-amber-400 font-extrabold">
            Archer Training
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-wider uppercase">
            HOW TO PLAY
          </h2>
        </div>

        {/* 4 Steps */}
        <div className="space-y-3 text-left">
          {/* Step 1 */}
          <div className="flex items-start gap-3 p-3 rounded-2xl bg-stone-950/70 border border-stone-800">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <MoveHorizontal size={18} />
            </div>
            <div>
              <div className="text-xs font-black text-amber-300 uppercase">STEP 1</div>
              <p className="text-xs text-stone-200 mt-0.5">
                <strong>Drag on the screen</strong> to align the golden trajectory dots toward the moving target.
              </p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="flex items-start gap-3 p-3 rounded-2xl bg-stone-950/70 border border-stone-800">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <span className="text-sm font-bold">🏹</span>
            </div>
            <div>
              <div className="text-xs font-black text-emerald-300 uppercase">STEP 2</div>
              <p className="text-xs text-stone-200 mt-0.5">
                Tap the large <strong>SHOOT</strong> button or release your finger to unleash the arrow.
              </p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="flex items-start gap-3 p-3 rounded-2xl bg-stone-950/70 border border-stone-800">
            <div className="w-9 h-9 rounded-xl bg-red-500/10 text-red-400 border border-red-500/30 flex items-center justify-center shrink-0">
              <Target size={18} />
            </div>
            <div>
              <div className="text-xs font-black text-red-300 uppercase">STEP 3</div>
              <p className="text-xs text-stone-200 mt-0.5">
                Hit the <strong>Bullseye</strong> for +100 pts or dead-center <strong>Perfect</strong> for +200 pts and massive combos!
              </p>
            </div>
          </div>

          {/* Step 4 */}
          <div className="flex items-start gap-3 p-3 rounded-2xl bg-stone-950/70 border border-stone-800">
            <div className="w-9 h-9 rounded-xl bg-sky-500/10 text-sky-400 border border-sky-500/30 flex items-center justify-center shrink-0">
              <Wind size={18} />
            </div>
            <div>
              <div className="text-xs font-black text-sky-300 uppercase">STEP 4</div>
              <p className="text-xs text-stone-200 mt-0.5">
                Watch the <strong>Wind Indicator</strong>! Strong winds push arrows left or right—aim into the wind to compensate.
              </p>
            </div>
          </div>
        </div>

        {/* Got It Button */}
        <div className="pt-2">
          <button
            id="tutorial-got-it-button"
            onClick={() => {
              soundManager.playButtonClick();
              onClose();
            }}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-500 text-stone-950 font-black text-base uppercase tracking-wider hover:brightness-110 active:scale-95 transition shadow-lg flex items-center justify-center gap-2 cursor-pointer"
          >
            <Check size={18} />
            <span>GOT IT!</span>
          </button>
        </div>
      </div>
    </div>
  );
};
