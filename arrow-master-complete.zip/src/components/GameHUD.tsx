import React from 'react';
import { Pause, Wind } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

interface GameHUDProps {
  levelNumber: number;
  levelName: string;
  score: number;
  coins: number;
  arrowsRemaining: number;
  maxArrows: number;
  combo: number;
  windSpeed: number;
  onShoot: () => void;
  onPause: () => void;
  canShoot: boolean;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  levelNumber,
  levelName,
  score,
  coins,
  arrowsRemaining,
  maxArrows,
  combo,
  windSpeed,
  onShoot,
  onPause,
  canShoot,
}) => {
  // Determine wind text & direction
  const absWind = Math.abs(windSpeed);
  const windDir = windSpeed > 0.1 ? '→' : windSpeed < -0.1 ? '←' : '•';
  const windStrengthText =
    absWind < 0.3 ? 'CALM' : absWind < 1.8 ? 'LIGHT' : absWind < 3.2 ? 'MODERATE' : 'STRONG';

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-3 sm:p-4 select-none z-10">
      {/* Top Header Bar */}
      <div className="flex items-center justify-between w-full gap-2">
        {/* Left: Arrows / Quiver */}
        <div className="flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-amber-500/20 shadow-lg pointer-events-auto">
          <span className="text-base sm:text-lg">🏹</span>
          <div className="flex items-center gap-1">
            {Array.from({ length: maxArrows }).map((_, idx) => (
              <div
                key={idx}
                className={`w-2.5 sm:w-3 h-5 sm:h-6 rounded-sm transition-all duration-300 ${
                  idx < arrowsRemaining
                    ? 'bg-gradient-to-t from-amber-600 to-amber-300 shadow-[0_0_6px_rgba(245,158,11,0.5)]'
                    : 'bg-stone-700/50 border border-stone-600/30'
                }`}
              />
            ))}
          </div>
          <span className="text-xs font-bold text-amber-200 ml-1">
            {arrowsRemaining}
          </span>
        </div>

        {/* Center: Level Title */}
        <div className="flex flex-col items-center">
          <div className="bg-gradient-to-r from-emerald-950/80 via-emerald-900/90 to-emerald-950/80 px-4 py-1 rounded-full border border-emerald-500/30 shadow-md">
            <span className="text-xs sm:text-sm font-extrabold tracking-wider text-emerald-200 uppercase">
              LEVEL {levelNumber}
            </span>
          </div>
          <span className="text-[10px] text-emerald-300/80 font-medium truncate max-w-[140px] text-center mt-0.5">
            {levelName}
          </span>
        </div>

        {/* Right: Coins & Pause */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Coins */}
          <div className="flex items-center gap-1.5 bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full border border-amber-500/20 shadow-lg">
            <span className="text-amber-400 text-sm sm:text-base font-bold">🪙</span>
            <span className="text-xs sm:text-sm font-bold text-amber-300">
              {coins.toLocaleString()}
            </span>
          </div>

          {/* Pause Button */}
          <button
            id="pause-button"
            onClick={() => {
              soundManager.playButtonClick();
              onPause();
            }}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-stone-900/80 border border-amber-500/30 flex items-center justify-center text-stone-200 hover:text-amber-400 hover:border-amber-400 active:scale-95 transition shadow-lg pointer-events-auto"
            aria-label="Pause game"
          >
            <Pause size={16} />
          </button>
        </div>
      </div>

      {/* Secondary Metrics Bar: Score, Combo & Wind */}
      <div className="flex items-center justify-between w-full mt-1">
        {/* Score */}
        <div className="flex flex-col">
          <span className="text-[10px] uppercase tracking-wider text-stone-400 font-bold">
            Score
          </span>
          <span className="text-xl sm:text-2xl font-black text-white tracking-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
            {score.toLocaleString()}
          </span>
        </div>

        {/* Combo Badge (Animated when active) */}
        {combo > 1 && (
          <div className="animate-bounce bg-gradient-to-r from-orange-600 via-amber-500 to-yellow-500 px-3 py-1 rounded-full shadow-[0_0_15px_rgba(245,158,11,0.6)] flex items-center gap-1 border border-yellow-200">
            <span className="text-xs sm:text-sm">🔥</span>
            <span className="text-xs sm:text-sm font-black text-black tracking-wider uppercase">
              COMBO x{combo}
            </span>
          </div>
        )}

        {/* Wind Indicator */}
        <div className="flex items-center gap-1.5 bg-black/40 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-sky-500/20">
          <Wind size={14} className="text-sky-400 animate-pulse" />
          <div className="flex flex-col items-end">
            <span className="text-[9px] uppercase tracking-wider text-sky-300 font-bold">
              {windDir} WIND {windDir}
            </span>
            <span className="text-[10px] font-extrabold text-sky-200">
              {windStrengthText} {absWind > 0.2 ? `(${absWind.toFixed(1)})` : ''}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom Area: Large SHOOT Button & Aim Instruction */}
      <div className="w-full flex flex-col items-center gap-2 pb-1 sm:pb-3 pointer-events-auto">
        <span className="text-[11px] text-amber-200/60 font-medium tracking-wide drop-shadow text-center">
          Drag on screen to aim • Tap SHOOT or release to fire
        </span>

        <button
          id="shoot-button"
          onClick={() => {
            if (canShoot && arrowsRemaining > 0) {
              // Call global trigger if canvas initialized
              if ((window as unknown as { triggerArrowShoot?: () => void }).triggerArrowShoot) {
                (window as unknown as { triggerArrowShoot: () => void }).triggerArrowShoot();
              } else {
                onShoot();
              }
            }
          }}
          disabled={!canShoot || arrowsRemaining <= 0}
          className={`w-full max-w-xs sm:max-w-sm h-14 sm:h-16 rounded-2xl font-black text-lg sm:text-xl tracking-wider uppercase transition-all duration-150 shadow-xl flex items-center justify-center gap-2 border-2 active:scale-95 ${
            canShoot && arrowsRemaining > 0
              ? 'bg-gradient-to-b from-amber-400 via-amber-500 to-amber-600 text-stone-950 border-amber-200 shadow-[0_8px_25px_rgba(245,158,11,0.5)] hover:brightness-110 active:brightness-90 cursor-pointer'
              : 'bg-stone-800/80 text-stone-500 border-stone-700/50 cursor-not-allowed opacity-60'
          }`}
        >
          <span className="text-xl">🏹</span>
          <span>SHOOT</span>
          <span className="text-xs bg-stone-900/30 px-2 py-0.5 rounded-full font-bold">
            {arrowsRemaining} left
          </span>
        </button>
      </div>
    </div>
  );
};
