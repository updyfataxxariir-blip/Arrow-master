/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { 
  GameScreen, 
  LevelConfig, 
  UserSaveState, 
  HitResult 
} from './types';
import { LEVELS } from './game/levels';
import { loadSaveState, saveGameState, clearSaveState } from './game/storage';
import { soundManager } from './audio/soundManager';

import { ArcheryCanvas } from './components/ArcheryCanvas';
import { GameHUD } from './components/GameHUD';
import { HomeScreen } from './components/HomeScreen';
import { LevelSelectModal } from './components/LevelSelectModal';
import { ShopModal } from './components/ShopModal';
import { AchievementsModal } from './components/AchievementsModal';
import { SettingsModal } from './components/SettingsModal';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { TutorialModal } from './components/TutorialModal';
import { PWAInstallBanner } from './components/PWAInstallBanner';

export default function App() {
  // Persistent user save state
  const [saveState, setSaveState] = useState<UserSaveState>(() => loadSaveState());

  // Screen & Navigation
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('home');
  const [activeModal, setActiveModal] = useState<
    'levels' | 'shop' | 'achievements' | 'settings' | 'tutorial' | 'complete' | 'gameover' | null
  >(null);

  // Active Level State
  const [currentLevel, setCurrentLevel] = useState<LevelConfig>(() => {
    const initialLevelId = Math.min(saveState.highestUnlockedLevel, 50);
    return LEVELS.find((l) => l.id === initialLevelId) || LEVELS[0];
  });

  const [arrowsRemaining, setArrowsRemaining] = useState<number>(currentLevel.arrowsCount);
  const [currentScore, setCurrentScore] = useState<number>(0);
  const [combo, setCombo] = useState<number>(0);
  const [coinsEarnedThisRound, setCoinsEarnedThisRound] = useState<number>(0);
  const [totalShots, setTotalShots] = useState<number>(0);
  const [successfulHits, setSuccessfulHits] = useState<number>(0);
  const [perfectHitsThisRound, setPerfectHitsThisRound] = useState<number>(0);
  const [bullseyesThisRound, setBullseyesThisRound] = useState<number>(0);
  const [canShoot, setCanShoot] = useState<boolean>(true);
  const [calculatedStars, setCalculatedStars] = useState<number>(1);

  // Initialize Sound and Music
  useEffect(() => {
    soundManager.setPreferences(
      saveState.soundEnabled,
      saveState.musicEnabled,
      saveState.vibrationEnabled
    );
  }, [saveState.soundEnabled, saveState.musicEnabled, saveState.vibrationEnabled]);

  // Save changes automatically
  const updateSaveState = useCallback((updater: (prev: UserSaveState) => UserSaveState) => {
    setSaveState((prev) => {
      const next = updater(prev);
      saveGameState(next);
      return next;
    });
  }, []);

  // Daily Offline Reward Calculation
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const canClaimDailyReward = saveState.lastDailyRewardDate !== todayDateStr;

  const handleClaimDailyReward = () => {
    if (!canClaimDailyReward) return;
    soundManager.playUnlock();
    updateSaveState((prev) => ({
      ...prev,
      coins: prev.coins + 150,
      lastDailyRewardDate: todayDateStr,
    }));
  };

  // Launch a Level
  const startLevel = useCallback((lvl: LevelConfig) => {
    setCurrentLevel(lvl);
    setArrowsRemaining(lvl.arrowsCount);
    setCurrentScore(0);
    setCombo(0);
    setCoinsEarnedThisRound(0);
    setTotalShots(0);
    setSuccessfulHits(0);
    setPerfectHitsThisRound(0);
    setBullseyesThisRound(0);
    setCanShoot(true);
    setCurrentScreen('playing');
    setActiveModal(null);

    // Show tutorial if first time playing
    if (!saveState.tutorialCompleted && lvl.id === 1) {
      setActiveModal('tutorial');
    }
  }, [saveState.tutorialCompleted]);

  // Arrow Shot Fired
  const handleShootArrow = useCallback(() => {
    setCanShoot(false);
    setArrowsRemaining((prev) => Math.max(0, prev - 1));
    setTotalShots((prev) => prev + 1);
  }, []);

  // Arrow Impact Handled
  const handleHitResult = useCallback((result: HitResult) => {
    const isHit = result.zone !== 'miss' && result.zone !== 'obstacle';

    if (isHit) {
      setSuccessfulHits((prev) => prev + 1);
      setCurrentScore((prev) => prev + result.score);
      setCoinsEarnedThisRound((prev) => prev + result.coinsEarned);

      // Increase Combo
      setCombo((prev) => {
        const nextCombo = prev + 1;
        // Update user lifetime max combo
        updateSaveState((s) => ({
          ...s,
          maxCombo: Math.max(s.maxCombo, nextCombo),
        }));
        return nextCombo;
      });

      if (result.isPerfect) {
        setPerfectHitsThisRound((prev) => prev + 1);
      }
      if (result.isBullseye) {
        setBullseyesThisRound((prev) => prev + 1);
      }

      // Update Lifetime Stats in storage
      updateSaveState((prev) => ({
        ...prev,
        coins: prev.coins + result.coinsEarned,
        totalHits: prev.totalHits + 1,
        totalBullseyes: prev.totalBullseyes + (result.isBullseye ? 1 : 0),
        totalPerfects: prev.totalPerfects + (result.isPerfect ? 1 : 0),
      }));
    } else {
      // Missed shot resets combo
      setCombo(0);
    }

    // Check if level should conclude or allow next shot
    setTimeout(() => {
      setArrowsRemaining((currentArrows) => {
        if (currentArrows > 0) {
          setCanShoot(true);
        } else {
          // Level round complete - evaluate score vs star thresholds
          setCurrentScore((finalScore) => {
            const passThreshold = currentLevel.starScores[0];
            const isCleared = finalScore >= passThreshold;

            if (isCleared) {
              // Calculate Stars (1-3)
              let earnedStars = 1;
              if (finalScore >= currentLevel.starScores[2]) {
                earnedStars = 3;
              } else if (finalScore >= currentLevel.starScores[1]) {
                earnedStars = 2;
              }
              setCalculatedStars(earnedStars);

              // Level clearance bonus coins
              const bonusCoins = 30 + earnedStars * 15;
              setCoinsEarnedThisRound((prev) => prev + bonusCoins);

              // Update Saved Level Progress
              updateSaveState((prev) => {
                const nextHighest = Math.min(50, Math.max(prev.highestUnlockedLevel, currentLevel.id + 1));
                const prevStars = prev.levelStars[currentLevel.id] || 0;
                const prevHigh = prev.levelHighScores[currentLevel.id] || 0;

                return {
                  ...prev,
                  coins: prev.coins + bonusCoins,
                  highestUnlockedLevel: nextHighest,
                  levelStars: {
                    ...prev.levelStars,
                    [currentLevel.id]: Math.max(prevStars, earnedStars),
                  },
                  levelHighScores: {
                    ...prev.levelHighScores,
                    [currentLevel.id]: Math.max(prevHigh, finalScore),
                  },
                };
              });

              setActiveModal('complete');
            } else {
              soundManager.playGameOver();
              setActiveModal('gameover');
            }
            return finalScore;
          });
        }
        return currentArrows;
      });
    }, 450);
  }, [currentLevel, updateSaveState]);

  // Navigation callbacks
  const handleNextLevel = () => {
    const nextLvl = LEVELS.find((l) => l.id === currentLevel.id + 1);
    if (nextLvl) {
      startLevel(nextLvl);
    } else {
      setCurrentScreen('home');
      setActiveModal(null);
    }
  };

  const handleReplayLevel = () => {
    startLevel(currentLevel);
  };

  const handleReturnHome = () => {
    setCurrentScreen('home');
    setActiveModal(null);
  };

  // Shop Purchases
  const handleBuyBow = (bowId: string, price: number) => {
    if (saveState.coins < price) return;
    updateSaveState((prev) => ({
      ...prev,
      coins: prev.coins - price,
      unlockedBows: [...prev.unlockedBows, bowId],
      selectedBow: bowId,
    }));
  };

  const handleEquipBow = (bowId: string) => {
    updateSaveState((prev) => ({
      ...prev,
      selectedBow: bowId,
    }));
  };

  const handleBuyArrow = (arrowId: string, price: number) => {
    if (saveState.coins < price) return;
    updateSaveState((prev) => ({
      ...prev,
      coins: prev.coins - price,
      unlockedArrows: [...prev.unlockedArrows, arrowId],
      selectedArrow: arrowId,
    }));
  };

  const handleEquipArrow = (arrowId: string) => {
    updateSaveState((prev) => ({
      ...prev,
      selectedArrow: arrowId,
    }));
  };

  // Claim Achievement
  const handleClaimAchievement = (achId: string, rewardCoins: number) => {
    updateSaveState((prev) => ({
      ...prev,
      coins: prev.coins + rewardCoins,
      achievementsClaimed: {
        ...prev.achievementsClaimed,
        [achId]: true,
      },
    }));
  };

  // Reset progress
  const handleResetProgress = () => {
    const cleared = clearSaveState();
    setSaveState(cleared);
    setCurrentLevel(LEVELS[0]);
    setCurrentScreen('home');
    setActiveModal(null);
  };

  // Calculate Accuracy
  const accuracyPercent = totalShots > 0 ? Math.round((successfulHits / totalShots) * 100) : 0;

  return (
    <div className="relative w-full h-full bg-[#0d1712] overflow-hidden select-none touch-none flex flex-col justify-center items-center">
      {/* Container with max portrait width for tablets/desktops */}
      <div className="relative w-full h-full max-w-lg mx-auto shadow-2xl flex flex-col overflow-hidden bg-[#0d1712]">
        
        {/* Screen 1: Home Screen */}
        {currentScreen === 'home' && (
          <>
            <HomeScreen
              saveState={saveState}
              onPlay={() => {
                const highestLevel = LEVELS.find((l) => l.id === saveState.highestUnlockedLevel) || LEVELS[0];
                startLevel(highestLevel);
              }}
              onOpenLevels={() => setActiveModal('levels')}
              onOpenShop={() => setActiveModal('shop')}
              onOpenAchievements={() => setActiveModal('achievements')}
              onOpenSettings={() => setActiveModal('settings')}
              onClaimDailyReward={handleClaimDailyReward}
              canClaimDailyReward={canClaimDailyReward}
            />
            {/* PWA Install Banner at Bottom of Home */}
            <div className="px-4 pb-2 z-20 w-full flex justify-center">
              <PWAInstallBanner />
            </div>
          </>
        )}

        {/* Screen 2: Active Gameplay */}
        {currentScreen === 'playing' && (
          <div className="relative w-full h-full overflow-hidden">
            {/* 60FPS Archery Canvas Engine */}
            <ArcheryCanvas
              level={currentLevel}
              bowId={saveState.selectedBow}
              arrowSkinId={saveState.selectedArrow}
              arrowsRemaining={arrowsRemaining}
              combo={combo}
              highGraphics={saveState.highGraphics}
              onShootArrow={handleShootArrow}
              onHitResult={handleHitResult}
              isPaused={activeModal !== null}
              canShoot={canShoot}
            />

            {/* In-Game HUD Overlay */}
            <GameHUD
              levelNumber={currentLevel.id}
              levelName={currentLevel.name}
              score={currentScore}
              coins={saveState.coins}
              arrowsRemaining={arrowsRemaining}
              maxArrows={currentLevel.arrowsCount}
              combo={combo}
              windSpeed={currentLevel.windSpeed}
              onShoot={handleShootArrow}
              onPause={() => setActiveModal('levels' === activeModal ? null : ('pause' as unknown as 'settings'))}
              canShoot={canShoot}
            />
          </div>
        )}

        {/* MODALS & OVERLAYS */}

        {/* Level Select Modal */}
        {activeModal === 'levels' && (
          <LevelSelectModal
            saveState={saveState}
            onSelectLevel={(lvl) => startLevel(lvl)}
            onBack={() => setActiveModal(null)}
          />
        )}

        {/* Shop Modal */}
        {activeModal === 'shop' && (
          <ShopModal
            saveState={saveState}
            onBuyBow={handleBuyBow}
            onEquipBow={handleEquipBow}
            onBuyArrow={handleBuyArrow}
            onEquipArrow={handleEquipArrow}
            onBack={() => setActiveModal(null)}
          />
        )}

        {/* Achievements Modal */}
        {activeModal === 'achievements' && (
          <AchievementsModal
            saveState={saveState}
            onClaimReward={handleClaimAchievement}
            onBack={() => setActiveModal(null)}
          />
        )}

        {/* Settings Modal */}
        {activeModal === 'settings' && (
          <SettingsModal
            saveState={saveState}
            onUpdateSettings={(partial) => updateSaveState((prev) => ({ ...prev, ...partial }))}
            onResetProgress={handleResetProgress}
            onOpenTutorial={() => setActiveModal('tutorial')}
            onBack={() => setActiveModal(null)}
          />
        )}

        {/* Pause Modal */}
        {activeModal === ('pause' as unknown as string) && (
          <PauseModal
            levelNumber={currentLevel.id}
            onResume={() => setActiveModal(null)}
            onRestart={handleReplayLevel}
            onOpenSettings={() => setActiveModal('settings')}
            onHome={handleReturnHome}
          />
        )}

        {/* Game Over Modal */}
        {activeModal === 'gameover' && (
          <GameOverModal
            score={currentScore}
            bestScore={saveState.levelHighScores[currentLevel.id] || 0}
            coinsEarned={coinsEarnedThisRound}
            levelNumber={currentLevel.id}
            onRetry={handleReplayLevel}
            onLevels={() => setActiveModal('levels')}
            onHome={handleReturnHome}
          />
        )}

        {/* Level Complete Modal */}
        {activeModal === 'complete' && (
          <LevelCompleteModal
            levelNumber={currentLevel.id}
            score={currentScore}
            accuracy={accuracyPercent}
            perfectHits={perfectHitsThisRound}
            coinsEarned={coinsEarnedThisRound}
            stars={calculatedStars}
            hasNextLevel={currentLevel.id < 50}
            onNextLevel={handleNextLevel}
            onReplay={handleReplayLevel}
            onHome={handleReturnHome}
          />
        )}

        {/* Tutorial Modal */}
        {activeModal === 'tutorial' && (
          <TutorialModal
            onClose={() => {
              updateSaveState((prev) => ({ ...prev, tutorialCompleted: true }));
              setActiveModal(null);
            }}
          />
        )}
      </div>
    </div>
  );
}
