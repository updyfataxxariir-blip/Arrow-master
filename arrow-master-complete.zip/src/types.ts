export type GameScreen = 
  | 'home' 
  | 'levels' 
  | 'shop' 
  | 'achievements' 
  | 'settings' 
  | 'playing' 
  | 'paused' 
  | 'gameover' 
  | 'complete';

export type HitZone = 'outer' | 'blue' | 'red' | 'yellow' | 'perfect' | 'obstacle' | 'miss';

export interface BowItem {
  id: string;
  name: string;
  description: string;
  perk: string;
  perkType: 'score_bonus' | 'steady_aim' | 'wind_resist' | 'fire_burst' | 'extra_coins' | 'none';
  perkValue: number;
  price: number;
  bodyColor: string;
  accentColor: string;
  stringColor: string;
  glowColor?: string;
}

export interface ArrowSkin {
  id: string;
  name: string;
  description: string;
  price: number;
  shaftColor: string;
  fletchColor: string;
  headColor: string;
  trailColor: string;
  glowColor?: string;
  particleType: 'classic' | 'silver' | 'gold' | 'fire' | 'ice' | 'lightning';
}

export interface ObstacleConfig {
  id: string;
  type: 'shield' | 'pendulum' | 'log';
  xRatio: number; // 0 to 1 across width
  yRatio: number; // 0 to 1 from top
  width: number;
  height: number;
  speed: number;
  range: number; // horizontal or angular range
}

export interface LevelConfig {
  id: number;
  name: string;
  arrowsCount: number;
  targetRadius: number; // base target radius in virtual units
  targetSpeed: number; // speed across canvas
  movementType: 'static' | 'horizontal' | 'sine' | 'pingpong' | 'accelerated' | 'figure8';
  windSpeed: number; // negative = left, positive = right (-5 to 5)
  windVariation: boolean;
  obstacles: ObstacleConfig[];
  starScores: [number, number, number]; // Score thresholds for 1, 2, and 3 stars
}

export interface StuckArrow {
  relX: number; // relative to target center
  relY: number;
  angle: number;
  skinId: string;
}

export interface FlyingArrow {
  x: number;
  y: number;
  vx: number;
  vy: number;
  angle: number;
  skinId: string;
  trail: { x: number; y: number; alpha: number }[];
  active: boolean;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
  maxLife: number;
  size: number;
  type: 'spark' | 'smoke' | 'wood' | 'gold' | 'star' | 'fire' | 'ice' | 'lightning' | 'classic' | 'silver';
}

export interface FloatingText {
  id: string;
  text: string;
  subtext?: string;
  x: number;
  y: number;
  color: string;
  scale: number;
  opacity: number;
  vy: number;
}

export interface HitResult {
  zone: HitZone;
  score: number;
  coinsEarned: number;
  accuracy: number; // 0 to 100%
  distanceToCenter: number;
  hitX: number;
  hitY: number;
  isBullseye: boolean;
  isPerfect: boolean;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  target: number;
  current: number;
  unlocked: boolean;
  rewardCoins: number;
}

export interface UserSaveState {
  coins: number;
  highestUnlockedLevel: number;
  levelStars: Record<number, number>;
  levelHighScores: Record<number, number>;
  selectedBow: string;
  unlockedBows: string[];
  selectedArrow: string;
  unlockedArrows: string[];
  totalBullseyes: number;
  totalPerfects: number;
  totalHits: number;
  maxCombo: number;
  soundEnabled: boolean;
  musicEnabled: boolean;
  vibrationEnabled: boolean;
  highGraphics: boolean;
  tutorialCompleted: boolean;
  lastDailyRewardDate: string | null;
  achievementsClaimed: Record<string, boolean>;
}
