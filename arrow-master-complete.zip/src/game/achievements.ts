import { Achievement, UserSaveState } from '../types';

export interface AchievementDef {
  id: string;
  title: string;
  description: string;
  icon: string;
  target: number;
  rewardCoins: number;
  getProgress: (state: UserSaveState) => number;
}

export const ACHIEVEMENTS_LIST: AchievementDef[] = [
  {
    id: 'first_bullseye',
    title: 'First Bullseye',
    description: 'Hit your very first bullseye in the center yellow ring.',
    icon: '🎯',
    target: 1,
    rewardCoins: 50,
    getProgress: (s) => s.totalBullseyes,
  },
  {
    id: 'perfect_archer',
    title: 'Perfect Archer',
    description: 'Achieve 10 dead-center Perfect Bullseye hits (+200 pts).',
    icon: '🔥',
    target: 10,
    rewardCoins: 200,
    getProgress: (s) => s.totalPerfects,
  },
  {
    id: 'sharpshooter',
    title: 'Sharpshooter',
    description: 'Clear the first 10 training and marksman levels.',
    icon: '🏹',
    target: 10,
    rewardCoins: 250,
    getProgress: (s) => Object.keys(s.levelStars).filter(k => (s.levelStars[Number(k)] || 0) > 0).length,
  },
  {
    id: 'coin_collector',
    title: 'Coin Collector',
    description: 'Accumulate 1,000 total coins in your offline treasury.',
    icon: '💰',
    target: 1000,
    rewardCoins: 150,
    getProgress: (s) => s.coins,
  },
  {
    id: 'combo_king',
    title: 'Combo King',
    description: 'Chain a streak of 10 consecutive target hits without missing.',
    icon: '⚡',
    target: 10,
    rewardCoins: 350,
    getProgress: (s) => s.maxCombo,
  },
  {
    id: 'arsenal_master',
    title: 'Arsenal Collector',
    description: 'Unlock at least 4 different bows in the armory.',
    icon: '🛡️',
    target: 4,
    rewardCoins: 400,
    getProgress: (s) => s.unlockedBows.length,
  },
  {
    id: 'star_collector',
    title: 'Stargazer',
    description: 'Earn 50 total gold stars across the archery tournament.',
    icon: '⭐',
    target: 50,
    rewardCoins: 500,
    getProgress: (s) => Object.values(s.levelStars).reduce((acc, stars) => acc + stars, 0),
  },
  {
    id: 'master_archer',
    title: 'Master Archer',
    description: 'Conquer all 50 championship levels of Arrow Master!',
    icon: '👑',
    target: 50,
    rewardCoins: 1500,
    getProgress: (s) => Object.keys(s.levelStars).filter(k => (s.levelStars[Number(k)] || 0) > 0).length,
  },
];

export function getEvaluatedAchievements(state: UserSaveState): Achievement[] {
  return ACHIEVEMENTS_LIST.map((def) => {
    const current = Math.min(def.target, def.getProgress(state));
    const unlocked = current >= def.target;
    return {
      id: def.id,
      title: def.title,
      description: def.description,
      icon: def.icon,
      target: def.target,
      current,
      unlocked,
      rewardCoins: def.rewardCoins,
    };
  });
}
