import { UserSaveState } from '../types';

const STORAGE_KEY = 'arrow_master_save_v1';

export const DEFAULT_SAVE_STATE: UserSaveState = {
  coins: 100, // starting coins for player satisfaction
  highestUnlockedLevel: 1,
  levelStars: {},
  levelHighScores: {},
  selectedBow: 'bow_wooden',
  unlockedBows: ['bow_wooden'],
  selectedArrow: 'arrow_classic',
  unlockedArrows: ['arrow_classic'],
  totalBullseyes: 0,
  totalPerfects: 0,
  totalHits: 0,
  maxCombo: 0,
  soundEnabled: true,
  musicEnabled: true,
  vibrationEnabled: true,
  highGraphics: true,
  tutorialCompleted: false,
  lastDailyRewardDate: null,
  achievementsClaimed: {},
};

export function loadSaveState(): UserSaveState {
  if (typeof window === 'undefined' || !window.localStorage) {
    return { ...DEFAULT_SAVE_STATE };
  }

  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return { ...DEFAULT_SAVE_STATE };
    }
    const parsed = JSON.parse(raw);

    // Merge cleanly with defaults to protect against corrupted or missing schema fields
    return {
      ...DEFAULT_SAVE_STATE,
      ...parsed,
      levelStars: parsed.levelStars || {},
      levelHighScores: parsed.levelHighScores || {},
      unlockedBows: Array.isArray(parsed.unlockedBows) && parsed.unlockedBows.length > 0 
        ? parsed.unlockedBows 
        : ['bow_wooden'],
      unlockedArrows: Array.isArray(parsed.unlockedArrows) && parsed.unlockedArrows.length > 0 
        ? parsed.unlockedArrows 
        : ['arrow_classic'],
      achievementsClaimed: parsed.achievementsClaimed || {},
    };
  } catch (err) {
    console.error('Failed to load Arrow Master save data, falling back to default:', err);
    return { ...DEFAULT_SAVE_STATE };
  }
}

export function saveGameState(state: UserSaveState): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Failed to write to localStorage:', err);
  }
}

export function clearSaveState(): UserSaveState {
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {}
  }
  return { ...DEFAULT_SAVE_STATE };
}
