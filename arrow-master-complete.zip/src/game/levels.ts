import { LevelConfig } from '../types';

export const LEVELS: LevelConfig[] = Array.from({ length: 50 }, (_, i) => {
  const levelNum = i + 1;

  // 1-5: Novice Range
  if (levelNum <= 5) {
    return {
      id: levelNum,
      name: levelNum === 1 ? 'First Flight' : `Target Practice ${levelNum}`,
      arrowsCount: 5,
      targetRadius: 48 - (levelNum - 1) * 2,
      targetSpeed: levelNum === 1 ? 0 : 0.8 + (levelNum - 1) * 0.25,
      movementType: levelNum === 1 ? 'static' : 'horizontal',
      windSpeed: 0,
      windVariation: false,
      obstacles: [],
      starScores: [150, 300, 550],
    };
  }

  // 6-10: Apprentice Range
  if (levelNum <= 10) {
    const sub = levelNum - 5;
    return {
      id: levelNum,
      name: `Forest Drift ${sub}`,
      arrowsCount: 5,
      targetRadius: 40 - sub * 1.5,
      targetSpeed: 1.5 + sub * 0.3,
      movementType: sub % 2 === 0 ? 'sine' : 'horizontal',
      windSpeed: 0,
      windVariation: false,
      obstacles: [],
      starScores: [200, 450, 750],
    };
  }

  // 11-20: Marksman Range (Dynamic Motion & Limited Arrows)
  if (levelNum <= 20) {
    const sub = levelNum - 10;
    const movement = sub % 3 === 0 ? 'sine' : sub % 3 === 1 ? 'pingpong' : 'horizontal';
    return {
      id: levelNum,
      name: `Marksman Trial ${sub}`,
      arrowsCount: sub > 6 ? 4 : 5,
      targetRadius: 34 - (sub * 0.5),
      targetSpeed: 2.2 + sub * 0.2,
      movementType: movement,
      windSpeed: sub > 5 ? (sub % 2 === 0 ? 1.5 : -1.5) : 0,
      windVariation: false,
      obstacles: [],
      starScores: [250, 500, 850],
    };
  }

  // 21-30: Obstacle Range (Shields & Pendulums)
  if (levelNum <= 30) {
    const sub = levelNum - 20;
    return {
      id: levelNum,
      name: `Shield Defense ${sub}`,
      arrowsCount: 4,
      targetRadius: 30 - (sub * 0.3),
      targetSpeed: 2.5 + sub * 0.2,
      movementType: sub % 2 === 0 ? 'pingpong' : 'sine',
      windSpeed: (sub % 3 - 1) * 1.8,
      windVariation: false,
      obstacles: [
        {
          id: `obs_${levelNum}_1`,
          type: 'shield',
          xRatio: 0.5,
          yRatio: 0.42,
          width: 38 + (sub % 3) * 6,
          height: 16,
          speed: 1.8 + sub * 0.15,
          range: 0.35,
        },
      ],
      starScores: [200, 420, 750],
    };
  }

  // 31-40: Wind Valley (Variable Wind, Gusts & Distant Targets)
  if (levelNum <= 40) {
    const sub = levelNum - 30;
    const windSign = sub % 2 === 0 ? 1 : -1;
    const baseWind = windSign * (2.2 + sub * 0.3);
    return {
      id: levelNum,
      name: `Gale Valley ${sub}`,
      arrowsCount: 4,
      targetRadius: 28 - (sub * 0.3),
      targetSpeed: 2.8 + sub * 0.2,
      movementType: sub % 3 === 0 ? 'accelerated' : 'sine',
      windSpeed: baseWind,
      windVariation: true,
      obstacles: sub > 5 ? [
        {
          id: `obs_${levelNum}_1`,
          type: 'shield',
          xRatio: 0.5,
          yRatio: 0.44,
          width: 40,
          height: 15,
          speed: 2.2,
          range: 0.4,
        }
      ] : [],
      starScores: [220, 480, 800],
    };
  }

  // 41-50: Grandmaster Trials (High Wind, Moving Shields, Precision Targets)
  const sub = levelNum - 40;
  const isFinal = levelNum === 50;
  const windDir = sub % 2 === 0 ? 1 : -1;
  const grandWind = windDir * (3.5 + sub * 0.3);

  return {
    id: levelNum,
    name: isFinal ? 'Crown of the Grandmaster' : `Grandmaster Trial ${sub}`,
    arrowsCount: 4,
    targetRadius: isFinal ? 24 : 26 - sub * 0.2,
    targetSpeed: 3.4 + sub * 0.2,
    movementType: sub % 2 === 0 ? 'accelerated' : 'pingpong',
    windSpeed: grandWind,
    windVariation: true,
    obstacles: [
      {
        id: `obs_${levelNum}_1`,
        type: 'shield',
        xRatio: 0.35,
        yRatio: 0.42,
        width: 36,
        height: 14,
        speed: 2.5 + sub * 0.15,
        range: 0.35,
      },
      ...(sub >= 6 ? [{
        id: `obs_${levelNum}_2`,
        type: 'shield' as const,
        xRatio: 0.65,
        yRatio: 0.32,
        width: 32,
        height: 14,
        speed: -2.8,
        range: 0.3,
      }] : []),
    ],
    starScores: [240, 520, 900],
  };
});
